// Lektion 12 „Lebenslanges Lernen“ – Facelift (Fahrschule Boost · Fahrlehrer Serband)
const pptxgen = require('pptxgenjs');
const fs = require('fs');
const path = require('path');
const { Deck, COL, FONT, SERIF, W, H, icon, finalize } = require('./lib');

const ONLY = process.env.ONLY ? process.env.ONLY.split(',').map(Number) : null;
const hasMedia = f => fs.existsSync(path.join(__dirname, 'media', f));
const hasArt = f => fs.existsSync(path.join(__dirname, 'art', f));

// ---------- kleine Bausteine ----------
const K = { c: true };
function footer(s, dark = false) {
  s.text('FAHRLEHRER SERBAND', { x: W - 3.3, y: 0.32, w: 2.8, h: 0.25, size: 10, bold: true, cs: 3, color: dark ? '4A5261' : COL.dim, align: 'right', name: '!!ft' });
}
function kicker(s, t, x, y, o = {}, anim) {
  return s.text(t.toUpperCase(), { x, y, w: o.w || 9, h: 0.35, size: o.size || 13, bold: true, cs: 5, color: o.color || COL.orange, name: o.name, align: o.align }, anim);
}
function title(s, t, x, y, w, h, o = {}, anim) {
  return s.text(t, { x, y, w, h, font: SERIF, size: o.size || 44, bold: o.bold ?? true, color: o.color || COL.txt, lsm: o.lsm || 0.95, name: o.name, align: o.align, valign: o.valign }, anim);
}
const run = (text, o = {}) => ({ text, options: o });
function chip(s, t, x, y, w, o = {}, anim) {
  return s.text(t, { x, y, w, h: o.h || 0.5, size: o.size || 16, bold: o.bold ?? true, color: o.color || COL.txt, fill: o.fill || COL.card2, shape: s.pres.shapes.ROUNDED_RECTANGLE, rr: 0.25, align: 'center', valign: 'middle', line: o.line, lw: o.lw, name: o.name }, anim);
}
// Handy-Rahmen mit Bildschirm (Bild)
function phone(s, img, x, y, w, o = {}, anim) {
  const h = w * 2.05, b = 0.09 * w / 1.0;
  const g = o.name || `ph${s.idx}_${s.n}`;
  const a1 = s.rrect(x, y, w, h, { fill: '0B0D11', line: o.frame || '3A4252', lw: 2, rr: 0.32 * w / 2, shadow: true, name: g + 'f' }, anim);
  const im = s.img(img, { x: x + b, y: y + b * 1.1, w: w - 2 * b, h: h - 2.2 * b, sizing: 'crop', round: false, name: g + 'i' }, anim ? [].concat(anim).map(a => ({ ...a, c: false, a: false })) : undefined);
  return [a1, im];
}

async function build() {
  const pres = new pptxgen();
  pres.layout = 'LAYOUT_WIDE';
  pres.title = 'Lektion 12 – Lebenslanges Lernen';
  pres.author = 'Fahrlehrer Serband · Fahrschule Boost';
  const deck = new Deck(pres);
  const I = {};
  for (const [k, n, c] of [
    ['car', 'LuCar', COL.orange], ['eye', 'LuEye', COL.orange], ['ear', 'LuEar', COL.orange], ['hand', 'LuHand', COL.orange],
    ['brain', 'LuBrain', COL.txt], ['phoneOff', 'LuSmartphone', COL.orange], ['eyeW', 'LuEye', COL.orange], ['brainO', 'LuBrainCircuit', COL.orange],
    ['check', 'LuCircleCheck', COL.green], ['checkK', 'LuCircleCheck', '4CAF72'], ['play', 'LuPlay', 'FFFFFF'], ['clock', 'LuTimer', COL.orange],
    ['users', 'LuUsers', COL.orange], ['monitor', 'LuMonitorSmartphone', COL.orange], ['user', 'LuUserCheck', COL.orange], ['list', 'LuClipboardList', COL.orange],
    ['book', 'LuBookOpen', COL.orange], ['brainG', 'LuBrain', COL.orange], ['glass', 'LuWine', COL.orange], ['alert', 'LuTriangleAlert', COL.orange],
    ['shield', 'LuShieldCheck', COL.orange], ['leaf', 'LuLeaf', COL.orange], ['award', 'LuAward', COL.orange], ['refresh', 'LuRefreshCw', COL.orange],
    ['heart', 'LuHeartPulse', COL.orange], ['cam', 'LuVideo', 'D9954C'], ['globe', 'LuGlobe', 'D9954C'], ['route', 'LuRoute', 'D9954C'],
    ['sun', 'LuSun', 'D9954C'], ['moon', 'LuMoon', 'D9954C'], ['q', 'LuMessageCircleQuestion', 'D9954C'], ['cube', 'LuBox', 'D9954C'],
    ['compass', 'LuCompass', 'C9A227'], ['infW', 'LuInfinity', '1A0E05'], ['film', 'LuClapperboard', 'D9954C'], ['infinity', 'LuInfinity', COL.orange], ['bike', 'LuBike', COL.orange],
    ['school', 'LuSchool', COL.orange], ['key', 'LuKeyRound', COL.orange], ['baby', 'LuUsers', COL.orange], ['ban', 'LuSmartphone', COL.red],
  ]) I[k] = await icon(n, c);

  // ============ 1 · TITEL ============
  {
    const s = deck.add({ bg: 'bg_bokeh.jpg', transition: 'fade', footer: false, notes: `
Begrüßung. Heute wird es kein normaler Theorieabend. Heute geht es um etwas, das euch ein Leben lang begleitet: das Lernen selbst. Ruhig anfangen, Blickkontakt, Namen der Neuen abfragen.
🖱 Alles baut sich von selbst auf.` });
    s.img('boost_logo.png', { x: 0.8, y: 0.7, w: 2.6, h: 2.6 * 203 / 517, name: '!!logo' }, { fx: 'fade', auto: true, dur: 900 });
    kicker(s, 'Lektion 12 · Grundstoff', 0.8, 2.75, { name: '!!kick' }, { fx: 'float', auto: true, a: true });
    title(s, 'Lebenslanges\nLernen', 0.75, 3.15, 9, 2.6, { size: 80, name: '!!t' }, { fx: 'rise', auto: true, a: true, dur: 1100 });
    s.text('Theorieunterricht Klasse B  ·  Fahrlehrer Serband', { x: 0.8, y: 5.95, w: 9, h: 0.45, size: 20, color: COL.muted, name: '!!sub' }, { fx: 'fade', auto: true, a: true });
  }

  // ============ 2 · FILM ============
  {
    const s = deck.add({ transition: 'black', footer: false, notes: `
Der Film startet von selbst (44 Sekunden). Licht aus, nichts sagen.
➜ Danach kurz überleiten: Bevor wir loslegen, eine Frage, auf die fast jeder falsch antwortet.` });
    s.rect(0, 0, W, H, { fill: '000000', name: '!!blk' });
    const vw = 12.2, vh = vw * 308 / 480;
    s.video('intro_film.mp4', { x: (W - vw) / 2, y: (H - vh) / 2, w: vw, h: vh, cover: 'intro_film_cover.jpg', dur: 45000, name: 'film' });
  }

  // ============ 3 · FRAGE ============
  {
    const s = deck.add({ bg: 'bg_orange.jpg', transition: 'black', notes: `
Die Frage groß stehen lassen. Noch nichts sagen. Zwei, drei Sekunden Stille aushalten.
🖱 1 Klick: Antwortmöglichkeiten erscheinen.
Jetzt abstimmen lassen: Nach der Prüfung? Nach einem Jahr? Nie? Hände hoch oder Zuruf. Antworten sammeln, nichts bewerten. Die meisten sagen „nach der Prüfung“. Antwort offen lassen, wir lösen sie später auf.` });
    footer(s);
    kicker(s, 'Eine Frage zum Start', 0.8, 1.2, {}, { fx: 'fade', auto: true });
    s.text([run('Wann hört man auf,\nAuto fahren zu '), run('lernen?', { color: COL.orange })], { x: 0.75, y: 1.65, w: 11.5, h: 2.9, font: SERIF, size: 66, bold: true, lsm: 0.95, name: '!!frage' }, { fx: 'rise', auto: true, a: true, dur: 1200 });
    const ans = ['Nach der Prüfung?', 'Nach einem Jahr?', 'Nie?'];
    ans.forEach((t, i) => chip(s, t, 0.8 + i * 3.55, 5.05, 3.25, { size: 22, h: 0.7, fill: COL.card2, line: '3A4455' }, { fx: 'rise', c: i === 0, a: i > 0, d: 0, dur: 600 }));
    s.text('Eure Meinung zählt. Es gibt kein Richtig oder Falsch.', { x: 0.8, y: 6.2, w: 10, h: 0.4, size: 17, italic: true, color: COL.muted }, { fx: 'fade', a: true });
  }

  // ============ 4 · LERNWEG (Zeitstrahl) ============
  {
    const s = deck.add({ bg: 'bg_road.jpg', transition: 'fade', notes: `
Ruhig und persönlich erzählen: Lernen hat nicht in der Fahrschule angefangen.
🖱 Klick 1: Als Kind. Schon als Kind sitzt man hinten im Auto und schaut sich alles von den Eltern ab, das Gute und das Schlechte.
🖱 Klick 2: Der Fahrrad-Führerschein in der Grundschule. Da habt ihr die ersten Verkehrsregeln gelernt, ohne es zu merken.
🖱 Klick 3: Dann die Fahrschule. Theorie und die ersten Fahrstunden. Da sitzen wir gerade.
🖱 Klick 4: Und dann das erste eigene Auto, ganz allein.
🖱 Klick 5: Wichtig, langsam sprechen: Die Straße hört bei der Prüfung nicht auf. Sie geht weiter, ein Leben lang. Das Unendlich-Zeichen stehen lassen.` });
    footer(s);
    kicker(s, 'Dein Lernweg', 0.8, 0.9);
    title(s, 'Lernen beginnt lange\nvor der Fahrschule', 0.75, 1.3, 10, 1.8, { size: 46 });
    const y = 4.55, xs = [1.7, 4.2, 6.7, 9.2, 11.65];
    s.lineS(0.8, y, 12.55, y, { color: '3A4252', lw: 3, dash: 'dash' });
    const fill = s.lineS(0.8, y, 12.55, y, { color: COL.orange, lw: 4, glow: 6 }, { fx: 'wipeR', auto: true, dur: 1800 });
    const st = [
      ['Als Kind', 'Rückbank, abgeschaut', I.baby, 'up'], ['Fahrrad-Führerschein', 'Grundschule', I.bike, 'down'],
      ['Fahrschule', 'Theorie & Praxis', I.school, 'up'], ['Erstes Auto', 'Ganz allein', I.key, 'down'], ['Ein Leben lang', 'Es geht weiter', I.infinity, 'up']];
    st.forEach(([t, sub, ic, pos], i) => {
      const x = xs[i], last = i === 4;
      s.oval(x - 0.42, y - 0.42, 0.84, 0.84, { fill: last ? COL.orange : '161B24', line: COL.orange, lw: 3, glow: last ? 14 : 6, glowOp: 0.5 }, { fx: 'zoom', c: true, dur: 500 });
      s.img(last ? I.infW : ic, { x: x - 0.24, y: y - 0.24, w: 0.48, h: 0.48 }, { fx: 'fade', dur: 400 });
      const ty = pos === 'up' ? y - 1.55 : y + 0.65;
      s.text(t, { x: x - 1.6, y: ty, w: 3.2, h: 0.5, font: SERIF, size: 22, bold: true, align: 'center' }, { fx: 'rise', a: true, dur: 500 });
      s.text(sub, { x: x - 1.6, y: ty + 0.5, w: 3.2, h: 0.4, size: 17, color: COL.muted, align: 'center' }, { fx: 'fade', dur: 500 });
    });
    if (fill) {}
  }

  // ============ 5 · ENDLICH FREI (Statement) ============
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
Den Moment ausmalen: das erste Mal allein im eigenen Auto. Musik an, Fenster runter, kein Fahrlehrer mehr daneben. Dieses Freiheitsgefühl kennt jeder.
🖱 1 Klick: Und genau hier kippt es. Keine Begleitung mehr, keine Kontrolle. Nur du, dein Auto und die Versuchung.` });
    title(s, 'Endlich frei.', 0.8, 2.0, 11.7, 1.6, { size: 96, align: 'center', name: '!!ef' }, { fx: 'fade', auto: true, dur: 1600 });
    s.text('Und genau jetzt wird es gefährlich.', { x: 0.8, y: 4.05, w: 11.7, h: 0.9, font: SERIF, size: 44, italic: true, color: COL.orange, align: 'center', glow: 10, glowOp: 0.35 }, { fx: 'rise', c: true, dur: 1000 });
  }

  // ============ 6 · VERSUCHUNGEN (Fotos) ============
  {
    const s = deck.add({ bg: 'bg_red.jpg', transition: 'fade', notes: `
Aufzählen: kurz aufs Handy, schnell telefonieren, müde weiterfahren, vor Freunden angeben. Genau da schleichen sich die schlechten Gewohnheiten ein.
🖱 4 Klicks: Jedes Bild einzeln. Pro Bild kurz fragen: Wer von euch hat das schon bei anderen gesehen?
➜ Überleitung zu den Zahlen.` });
    footer(s);
    kicker(s, 'Die Versuchung fährt mit', 0.8, 0.9, { color: COL.red });
    title(s, 'Genau da schleichen sich\ndie Gewohnheiten ein', 0.75, 1.3, 11, 1.6, { size: 42 });
    const ph = [['p_handy.jpg', 'Kurz aufs Handy'], ['p_telefon.jpg', 'Nur schnell telefonieren'], ['p_muede.jpg', 'Müde weiterfahren'], ['p_angeben.jpg', 'Vor Freunden angeben']];
    const cw = 2.85, gap = 0.2, x0 = (W - (4 * cw + 3 * gap)) / 2;
    ph.forEach(([f, t], i) => {
      const x = x0 + i * (cw + gap);
      s.img(f, { x, y: 3.25, w: cw, h: 3.0, sizing: 'crop', shadow: true }, { fx: 'rise', c: true, dur: 700 });
      s.text(t, { x, y: 6.35, w: cw, h: 0.45, size: 19, bold: true, align: 'center' }, { fx: 'fade', dur: 500 });
    });
  }

  // ============ 7–10 · STATISTIK-SEQUENZ (Wette, Rennen, Alter, Pointe) ============
  await require('./stats').statsSlides(deck, { COL, SERIF, W, footer, kicker, title, chip, run, I, pres, icon });

  // ============ 9 · LERNT MAN JE AUS? (Morph-Start) ============
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
Jetzt kommt die Auflösung der Eingangsfrage. Die Frage leise in den Raum stellen, kurz warten.
➜ Weiterklicken: Die Antwort fährt per Morph herein.` });
    title(s, 'Lernt man je aus?', 0.8, 2.9, 11.7, 1.4, { size: 72, align: 'center', name: '!!q' }, { fx: 'fade', auto: true, dur: 1400 });
    s.text('Nein.', { x: 0.8, y: 8.2, w: 11.7, h: 2.2, font: SERIF, size: 150, bold: true, color: COL.orange, align: 'center', name: '!!nein' });
  }
  // ============ 10 · NEIN. ============
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'morph', dur: 1400, footer: false, notes: `
Kraftvoll und ruhig: Nein. Man lernt nie aus. Ein guter Fahrer lernt sein Leben lang. Genau das ist lebenslanges Lernen. Das ist der Kern des heutigen Themas.
🖱 1 Klick: der Satz darunter.` });
    title(s, 'Lernt man je aus?', 0.8, 0.8, 11.7, 0.9, { size: 36, align: 'center', color: COL.muted, name: '!!q' });
    s.text('Nein.', { x: 0.8, y: 1.9, w: 11.7, h: 2.3, font: SERIF, size: 160, bold: true, color: COL.orange, align: 'center', valign: 'middle', glow: 18, glowOp: 0.35, name: '!!nein' });
    s.text('Man lernt nie aus. Ein guter Fahrer lernt sein Leben lang.\nGenau das ist lebenslanges Lernen.', { x: 1.2, y: 4.7, w: 10.9, h: 1.3, font: SERIF, size: 30, italic: true, align: 'center', lsm: 1.1 }, { fx: 'rise', c: true, dur: 900 });
  }

  // ============ 11 · PROBEZEIT (Rahmenplan) ============
  {
    const s = deck.add({ bg: 'bg_blue.jpg', transition: 'fade', notes: `
Rahmenplan-Pflichtinhalt Grundstoff 12. Kurz und sachlich halten.
Der Gesetzgeber sieht das genauso: Nach der Prüfung beginnt eine Lernphase mit klaren Regeln, die Probezeit. Zwei Jahre (§ 2a StVG).
🖱 Klick 1: 0,0 Promille. Während der Probezeit und vor dem 21. Geburtstag gilt Alkohol- und Cannabisverbot am Steuer (§ 24c StVG).
🖱 Klick 2: Ein schwerer Verstoß (A) oder zwei weniger schwere (B): Aufbauseminar, und die Probezeit verlängert sich um zwei Jahre, also auf insgesamt vier (§ 2a Abs. 2 Nr. 1, Abs. 2a StVG).
🖱 Klick 3: Weitere Verstöße: schriftliche Verwarnung und Empfehlung, innerhalb von zwei Monaten eine verkehrspsychologische Beratung zu besuchen. Bei erneuten Verstößen nach Ablauf dieser Frist wird die Fahrerlaubnis entzogen (§ 2a Abs. 2 Nr. 2 und 3 StVG).
❓ Frage an die Klasse: Warum macht der Gesetzgeber das gerade bei Anfängern? ✅ Weil das Risiko am Anfang am höchsten ist (siehe Balken eben).` });
    footer(s);
    kicker(s, 'Was der Gesetzgeber sagt', 0.8, 0.9, { color: COL.blue });
    title(s, 'Die Probezeit: zwei Jahre Lernen\nmit klaren Regeln', 0.75, 1.3, 11.5, 1.7, { size: 42 });
    const rows = [[I.glass, '0,0 Promille', 'In der Probezeit und bis 21: kein Alkohol und kein Cannabis am Steuer.', '§ 24c StVG'],
      [I.alert, 'Aufbauseminar', 'Ein schwerer (A) oder zwei weniger schwere Verstöße (B): Seminarpflicht, Probezeit verlängert sich um 2 auf 4 Jahre.', '§ 2a StVG'],
      [I.shield, 'Verwarnung, dann Entzug', 'Weitere Verstöße: Verwarnung, Beratung binnen 2 Monaten empfohlen. Danach wird die Fahrerlaubnis entzogen.', '§ 2a StVG']];
    rows.forEach(([ic, t, d, p], i) => {
      const y = 3.25 + i * 1.2;
      s.rrect(0.8, y, 11.7, 1.02, { fill: COL.card, line: '2A3342', rr: 0.12 }, { fx: 'flyL', c: true, dur: 700 });
      s.oval(1.05, y + 0.16, 0.7, 0.7, { fill: '1E2635' }, { fx: 'fade', dur: 300 });
      s.img(ic, { x: 1.2, y: y + 0.31, w: 0.4, h: 0.4 }, { fx: 'fade', dur: 300 });
      s.text(t, { x: 2.0, y: y + 0.12, w: 3.6, h: 0.8, font: SERIF, size: 24, bold: true, valign: 'middle' }, { fx: 'fade', dur: 300 });
      s.text(d, { x: 5.6, y: y + 0.1, w: 5.3, h: 0.84, size: 16, color: COL.muted, valign: 'middle' }, { fx: 'fade', dur: 300 });
      s.text(p, { x: 10.95, y: y + 0.12, w: 1.4, h: 0.8, size: 13, bold: true, color: COL.blue, align: 'right', valign: 'middle' }, { fx: 'fade', dur: 300 });
    });
  }

  // ============ 12 · WEITERLERNEN NACH DER PRÜFUNG (Rahmenplan) ============
  {
    const s = deck.add({ bg: 'bg_blue.jpg', transition: 'fade', notes: `
Rahmenplan-Pflichtinhalt. Lernen hört auch mit der Probezeit nicht auf. Vier Wege, freiwillig besser zu werden.
🖱 4 Klicks, je eine Kachel:
1. Fahrsicherheitstraining: Gefahrenbremsung und Ausweichen auf abgesperrter Fläche üben.
2. Fahreignungsseminar: freiwillig, bei 1 bis 5 Punkten in Flensburg gibt es einen Punkt Abzug, höchstens einmal in fünf Jahren (§ 4 Abs. 7 StVG).
3. Spritsparend und umweltschonend fahren: vorausschauend fahren, früh hochschalten, rollen lassen. Spart Geld und Nerven.
4. Verkehrspsychologische Beratung: freiwillig und vertraulich, hilft wenn man merkt, dass man sich selbst im Weg steht.` });
    footer(s);
    kicker(s, 'Nach der Prüfung', 0.8, 0.9, { color: COL.blue });
    title(s, 'Wer gut bleiben will, lernt weiter', 0.75, 1.3, 12, 1.0, { size: 42 });
    const tiles = [[I.shield, 'Sicherheits-\ntraining', 'Bremsen und Ausweichen auf abgesperrter Fläche üben'],
      [I.award, 'Fahreignungs-\nseminar', 'Freiwillig: bei 1–5 Punkten ein Punktabzug (§ 4 Abs. 7 StVG)'],
      [I.leaf, 'Umwelt-\nschonend fahren', 'Vorausschauend, früh hochschalten, rollen lassen'],
      [I.heart, 'Verkehrs-\npsychologische\nBeratung', 'Freiwillig und vertraulich, wenn du dir selbst im Weg stehst']];
    const tw = 2.8, gap = 0.2, x0 = (W - (4 * tw + 3 * gap)) / 2;
    tiles.forEach(([ic, t, d], i) => {
      const x = x0 + i * (tw + gap);
      s.rrect(x, 2.75, tw, 3.85, { fill: COL.card, line: '2A3342', rr: 0.14, shadow: true }, { fx: 'rise', c: true, dur: 650 });
      s.img(ic, { x: x + 0.3, y: 3.05, w: 0.7, h: 0.7 }, { fx: 'zoom', dur: 400 });
      s.text(t, { x: x + 0.3, y: 3.9, w: tw - 0.45, h: 1.3, font: SERIF, size: 20, bold: true }, { fx: 'fade', dur: 400 });
      s.text(d, { x: x + 0.3, y: 5.25, w: tw - 0.45, h: 1.25, size: 15, color: COL.muted }, { fx: 'fade', dur: 400 });
    });
  }

  // ============ 13 · REFORM ============
  {
    const s = deck.add({ bg: 'bg_orange.jpg', transition: 'fade', notes: `
Überleitung: Und ausgerechnet jetzt ändert sich, wie ihr lernen werdet. Gestern gegen Morgen aufbauen.
🖱 Klick 1: Gestern: Präsenzpflicht. Du musstest in die Fahrschule kommen. Morgen: flexibel, Präsenz, online oder gemischt.
🖱 Klick 2: Gestern: Vorgabe. Die Fahrschule sagt dir, was und wie. Morgen: Eigenverantwortung. Du entscheidest und übernimmst Verantwortung.
🖱 Klick 3: Gestern: Stoff auswendig lernen. Morgen: verstehen, anwenden, dranbleiben.
Rechtsstand: 4. EU-Führerscheinrichtlinie (EU) 2025/2205, in Kraft seit 25.11.2025. Deutsche Fahrschulreform: Kabinettsbeschluss 20.05.2026, geplantes Inkrafttreten 01.01.2027. Das Gesetzgebungsverfahren ist noch nicht abgeschlossen, also als „geplant“ formulieren.` });
    footer(s);
    kicker(s, 'Neu · Die große Reform 2026/2027', 0.8, 0.9);
    title(s, 'Die Reform ändert, wie ihr lernt', 0.75, 1.3, 12, 1.0, { size: 44 });
    s.text('GESTERN', { x: 0.8, y: 2.6, w: 5.2, h: 0.6, font: SERIF, size: 30, bold: true, color: '5B6474', cs: 4 }, { fx: 'fade', auto: true });
    s.text('MORGEN', { x: 7.1, y: 2.6, w: 5.4, h: 0.6, font: SERIF, size: 30, bold: true, color: COL.orange, cs: 4, glow: 10, glowOp: 0.35 }, { fx: 'fade', auto: true, a: true });
    const rows = [['Präsenz', 'Du musst zur Fahrschule kommen', 'Flexibel', 'Lernen, wann und wo es für dich passt'],
      ['Vorgabe', 'Die Fahrschule sagt dir, was und wie', 'Eigenverantwortung', 'Du entscheidest und übernimmst Verantwortung'],
      ['Stoff lernen', 'Auswendig lernen steht im Fokus', 'Verstehen', 'Anwenden und dranbleiben']];
    rows.forEach(([a, ad, b, bd], i) => {
      const y = 3.4 + i * 1.12;
      s.rrect(0.8, y, 5.3, 0.95, { fill: '10141B', line: '232A36', rr: 0.1 }, { fx: 'fade', c: true, dur: 400 });
      s.text(a, { x: 1.05, y: y + 0.08, w: 4.9, h: 0.42, size: 20, bold: true, color: '8A93A2' }, { fx: 'fade', dur: 400 });
      s.text(ad, { x: 1.05, y: y + 0.48, w: 4.9, h: 0.4, size: 15, color: '6E7888' }, { fx: 'fade', dur: 400 });
      s.lineS(6.3, y + 0.475, 6.9, y + 0.475, { color: COL.orange, lw: 2.5, endArrow: 'triangle' }, { fx: 'wipeR', a: true, dur: 350 });
      s.rrect(7.1, y, 5.4, 0.95, { fill: COL.card2, line: COL.orange, lw: 1.25, rr: 0.1, glow: 6, glowOp: 0.25 }, { fx: 'flyR', a: true, dur: 650 });
      s.text(b, { x: 7.35, y: y + 0.08, w: 5.0, h: 0.42, size: 20, bold: true, color: COL.txt }, { fx: 'fade', dur: 650 });
      s.text(bd, { x: 7.35, y: y + 0.48, w: 5.0, h: 0.4, size: 15, color: COL.muted }, { fx: 'fade', dur: 650 });
    });
    s.text('4. EU-Führerscheinrichtlinie 2025/2205 (in Kraft seit 11/2025) · Kabinettsbeschluss 05/2026 · geplantes Inkrafttreten 2027 (Stand: Entwurf)', { x: 0.8, y: 6.9, w: 11.7, h: 0.3, size: 12, color: '9AA3AE' });
  }

  // ============ 14 · FREIHEIT = GEFAHR ============
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
Wichtiger Punkt: Das klingt gut, ist aber auch eine Gefahr. Wer nicht weiß, wie er selbst lernt, verliert den Faden. Genau darauf bereite ich euch heute vor.
🖱 1 Klick: der zweite Satz.` });
    title(s, 'Mehr Freiheit klingt gut.', 0.8, 2.2, 11.7, 1.2, { size: 60, align: 'center' }, { fx: 'fade', auto: true, dur: 1200 });
    s.text([run('Aber wer nicht weiß, '), run('wie er lernt,', { color: COL.orange }), run('\nverliert den Faden.')], { x: 0.8, y: 3.7, w: 11.7, h: 1.8, font: SERIF, size: 40, italic: true, align: 'center', lsm: 1.1 }, { fx: 'rise', c: true, dur: 1000 });
  }

  // ============ 15 · JEDER LERNT ANDERS ============
  {
    const s = deck.add({ bg: 'bg_center.jpg', transition: 'fade', notes: `
Positive Wendung: Die gute Nachricht ist, jeder hat seinen eigenen Lernweg.
Es gibt drei Hauptwege, wie Wissen in den Kopf kommt. Keiner ist besser als der andere. Ehrlich bleiben: Das ist ein vereinfachtes Modell, keine feste Schublade. Feste Lerntypen sind wissenschaftlich umstritten. Die meisten sind eine Mischung, und am besten lernt man mit mehreren Kanälen.
🖱 3 Klicks, je ein Kanal:
Sehen: Bilder, Videos, Skizzen. Beispiel: Du liest eine Verkehrssituation wie ein Bild. Auch Lesen und Mitschreiben gehört für die meisten hierher.
Hören: Erklärungen und Gespräche. Beispiel: Du verstehst es, sobald ich es dir erkläre.
Machen: Ausprobieren und erleben. Beispiel: In der Fahrstunde geht dir das Licht auf.
❓ Frage an die Klasse: Worin erkennt ihr euch wieder?` });
    footer(s);
    kicker(s, 'Die gute Nachricht', 0.8, 0.9);
    title(s, 'Jeder lernt anders', 0.75, 1.3, 12, 1.0, { size: 48 });
    s.text('Drei Wege, wie Wissen in deinen Kopf kommt. Keiner ist besser als der andere.', { x: 0.8, y: 2.3, w: 11.7, h: 0.5, size: 21, color: COL.muted }, { fx: 'fade', auto: true });
    const ch = [[I.eye, 'Sehen', 'Bilder, Videos, Skizzen', 'Du liest eine Verkehrssituation wie ein Bild.'],
      [I.ear, 'Hören', 'Erklärungen, Gespräche', 'Du verstehst es, sobald es dir jemand erklärt.'],
      [I.hand, 'Machen', 'Ausprobieren, Erleben', 'In der Fahrstunde geht dir das Licht auf.']];
    const cw = 3.7, gap = 0.3, x0 = (W - (3 * cw + 2 * gap)) / 2;
    ch.forEach(([ic, t, a, b], i) => {
      const x = x0 + i * (cw + gap);
      s.rrect(x, 3.1, cw, 3.45, { fill: COL.card, line: '2A3342', rr: 0.14, shadow: true }, { fx: 'rise', c: true, dur: 650 });
      s.oval(x + cw / 2 - 0.55, 3.35, 1.1, 1.1, { fill: '241A12', line: COL.orange, lw: 2, glow: 10, glowOp: 0.4 }, { fx: 'zoom', a: true, dur: 400 });
      s.img(ic, { x: x + cw / 2 - 0.32, y: 3.58, w: 0.64, h: 0.64 }, { fx: 'fade', dur: 400 });
      s.text(t, { x, y: 4.6, w: cw, h: 0.6, font: SERIF, size: 32, bold: true, align: 'center' }, { fx: 'fade', dur: 400 });
      s.text(a, { x, y: 5.2, w: cw, h: 0.4, size: 18, bold: true, color: COL.orange, align: 'center' }, { fx: 'fade', dur: 400 });
      s.text(b, { x: x + 0.3, y: 5.65, w: cw - 0.6, h: 0.75, size: 16, color: COL.muted, align: 'center' }, { fx: 'fade', dur: 400 });
    });
    s.text('Vereinfachtes Modell der Wahrnehmungskanäle, in Anlehnung an F. Vester. Wissenschaftlich umstritten: Am besten lernt man mit mehreren Kanälen.', { x: 0.8, y: 6.85, w: 11.7, h: 0.3, size: 12, color: '9AA3AE' });
  }

  // ============ 16 · DEINE MISCHUNG ============
  {
    const s = deck.add({ bg: 'bg_center.jpg', transition: 'fade', notes: `
Beispielhafte Mischung zeigen. Betonen: Das ist ein Beispiel, deine eigene Mischung sieht anders aus, und das ist völlig normal. Meist sind mehrere Kanäle stark.
🖱 Baut sich von selbst auf.` });
    footer(s);
    kicker(s, 'Niemand ist nur ein Typ', 0.8, 0.9);
    title(s, 'Deine Mischung', 0.75, 1.3, 6, 1.0, { size: 48 });
    const ch = s.nm();
    s.s.addChart(pres.charts.DOUGHNUT, [{ name: 'Mischung', labels: ['Sehen', 'Machen', 'Hören'], values: [45, 35, 20] }], {
      x: 0.9, y: 2.35, w: 4.6, h: 4.3, holeSize: 62, chartColors: [COL.orange, COL.amber, '5B6474'], showLegend: false, showValue: false, showPercent: false, showLabel: false,
      dataBorder: { pt: 2, color: '07080B' }, objectName: ch });
    s.reg(ch, { fx: 'zoom', auto: true, dur: 900 }, 'pic');
    s.text('Beispiel', { x: 2.2, y: 4.2, w: 2.0, h: 0.6, font: SERIF, size: 24, bold: true, align: 'center', color: COL.muted }, { fx: 'fade', auto: true, a: true });
    const bars = [['Sehen', 45, COL.orange], ['Machen', 35, COL.amber], ['Hören', 20, '8A93A2']];
    bars.forEach(([l, v, c], i) => {
      const y = 2.85 + i * 1.15;
      s.text(l, { x: 6.3, y, w: 3, h: 0.45, size: 22, bold: true }, { fx: 'fade', auto: true, a: true, dur: 300 });
      s.text(v + ' %', { x: 10.9, y, w: 1.5, h: 0.45, size: 22, bold: true, color: c, align: 'right' }, { fx: 'fade', auto: true, dur: 300 });
      s.rrect(6.3, y + 0.55, 6.1, 0.22, { fill: '1E2430', rr: 0.11 });
      s.rrect(6.3, y + 0.55, 6.1 * v / 50, 0.22, { fill: c, rr: 0.11, glow: 6, glowOp: 0.35 }, { fx: 'wipeR', auto: true, dur: 700 });
    });
    s.text('So könnte eine Mischung aussehen. Deine eigene ist wahrscheinlich anders, und das ist völlig normal.', { x: 6.3, y: 6.35, w: 6.1, h: 0.6, size: 15, italic: true, color: COL.muted }, { fx: 'fade', auto: true, a: true });
  }

  // ============ 17 · LERNTYP-TEST (QR) ============
  {
    const s = deck.add({ bg: 'bg_orange.jpg', transition: 'fade', notes: `
Überleitung: Ihr müsst nicht raten. Ihr könnt es herausfinden.
🖱 1 Klick: QR-Code erscheint. Jetzt alle Handys raus. Wichtig: Das bereitet auch den Schluss vor.
QR-Code scannen lassen, der Kurzcheck hat 18 Fragen und dauert etwa 2 Minuten. Es wird nichts gespeichert. Ein, zwei Ergebnisse laut vorlesen lassen.
VORHER PRÜFEN: QR-Code einmal selbst scannen, ob er funktioniert (serband1995-hue.github.io/Fahrlehrer-Kompass-/check.html).` });
    footer(s);
    kicker(s, 'Finde es heraus', 0.8, 0.9);
    title(s, 'Welcher Lerntyp\nbist du?', 0.75, 1.3, 5.2, 2.2, { size: 54 });
    s.text('Handy raus. QR-Code scannen.\nDein Ergebnis kommt sofort aufs Handy.', { x: 0.8, y: 3.9, w: 5.0, h: 1.0, size: 20, color: COL.muted, lsm: 1.1 }, { fx: 'fade', auto: true });
    ['18 Fragen', 'ca. 2 Minuten', 'nichts wird gespeichert'].forEach((t, i) => chip(s, t, 0.8, 5.2 + i * 0.6, 3.4, { size: 16, fill: COL.card2, line: '3A4455' }, { fx: 'flyL', auto: true, a: true, dur: 450 }));
    phone(s, 'lt_start.jpg', 6.0, 0.85, 2.85, { name: 'ltph' }, { fx: 'rise', auto: true, a: true, dur: 900 });
    s.rrect(9.55, 1.7, 3.1, 3.1, { fill: 'FFFFFF', rr: 0.08, shadow: true, glow: 16, glowColor: COL.orange, glowOp: 0.35 }, { fx: 'zoom', c: true, dur: 600 });
    s.img('qr_check.png', { x: 9.7, y: 1.85, w: 2.8, h: 2.8, alt: 'QR-Code zum Lerntyp-Kurzcheck' }, { fx: 'fade', dur: 300 });
    s.text('Einfach scannen', { x: 9.55, y: 5.0, w: 3.1, h: 0.5, size: 20, bold: true, align: 'center', color: COL.orange }, { fx: 'fade', dur: 300 });
  }

  // ============ 18 · DREI TYPEN ============
  {
    const s = deck.add({ bg: 'bg_orange.jpg', transition: 'fade', notes: `
Auflösung des Kurzchecks: Wer ist was? Handzeichen.
🖱 3 Klicks, je ein Typ. Pro Typ fragen: Wer hat diesen Typ bekommen?
Der Seher lernt über die Augen. Der Denker über Sprache und Erklärung. Der Macher im Tun.
Betonen: Kaum jemand ist nur ein Typ.` });
    footer(s);
    kicker(s, 'Dein Ergebnis', 0.8, 0.9);
    title(s, 'Seher, Denker oder Macher?', 0.75, 1.3, 12, 1.0, { size: 44 });
    const t = [[I.eye, 'Der Seher', 'Du nimmst am meisten über die Augen auf.', 'Skizze, kurzes Video, Strecke vorab auf der Karte.'],
      [I.ear, 'Der Denker', 'Du verstehst über Sprache und Erklärung.', 'Beim Fahren laut mitsprechen, nach dem Warum fragen.'],
      [I.hand, 'Der Macher', 'Du lernst im Tun, nicht in der Theorie.', 'Kurz erklären lassen, dann sofort üben.']];
    const cw = 3.7, gap = 0.3, x0 = (W - (3 * cw + 2 * gap)) / 2;
    t.forEach(([ic, n, a, b], i) => {
      const x = x0 + i * (cw + gap);
      s.rrect(x, 2.7, cw, 3.8, { fill: COL.card, line: '2A3342', rr: 0.14, shadow: true }, { fx: 'flyB', c: true, dur: 800 });
      s.img(ic, { x: x + 0.35, y: 3.0, w: 0.7, h: 0.7 }, { fx: 'zoom', a: true, dur: 350 });
      s.text('Kanal: ' + ['Sehen', 'Hören', 'Machen'][i], { x: x + 1.2, y: 3.15, w: cw - 1.4, h: 0.4, size: 15, bold: true, color: COL.orange, valign: 'middle' }, { fx: 'fade', dur: 350 });
      s.text(n, { x: x + 0.35, y: 3.85, w: cw - 0.6, h: 0.6, font: SERIF, size: 32, bold: true }, { fx: 'fade', dur: 350 });
      s.text(a, { x: x + 0.35, y: 4.5, w: cw - 0.6, h: 0.8, size: 18, bold: true, color: COL.txt }, { fx: 'fade', dur: 350 });
      s.text('Konkret: ' + b, { x: x + 0.35, y: 5.35, w: cw - 0.6, h: 0.95, size: 16, color: COL.muted }, { fx: 'fade', dur: 350 });
    });
  }

  // ============ 19 · EURE MISSION ============
  {
    const s = deck.add({ bg: 'bg_center.jpg', transition: 'zoom', notes: `
Jetzt kommt die Gruppenarbeit. Arbeitsblätter austeilen, drei Gruppen bilden: Sehen, Hören, Machen (bei großer Klasse je Kanal zwei Gruppen).
🖱 1 Klick: der Auftrag. 🖱 2. Klick: Timer.
MISSION: Findet drei konkrete Lerntipps für euren Lerntyp. 15 Minuten. Sag klar: Konkret heißt, was genau tut die Person, wann und womit. Nicht „Videos gucken“, sondern „abends 20 Minuten Lernvideos zu einem Themenblock“. Eine Person pro Gruppe stellt später vor.
Du gehst herum. Wenn eine Gruppe hängt, stell eine Frage von den Denkanstößen auf dem Arbeitsblatt, gib keine Lösung. Zusatzauftrag für schnelle Gruppen: Findet einen vierten Tipp, der nichts kostet und keine App braucht.` });
    footer(s);
    s.img('mission.png', { x: 0.9, y: 0.75, w: 4.3, h: 4.3 * 1536 / 1024 * 0.93, rotate: -4, shadow: true }, { fx: 'zoom', auto: true, dur: 900 });
    kicker(s, 'Gruppenarbeit', 6.0, 1.1);
    title(s, 'Drei Gruppen.\nDrei Lernkanäle.', 5.95, 1.5, 7, 1.8, { size: 46 });
    s.text([run('Findet '), run('3 konkrete Lerntipps', { color: COL.orange, bold: true }), run(' für euren Lerntyp.')], { x: 6.0, y: 3.45, w: 6.6, h: 0.6, size: 24 }, { fx: 'fade', c: true });
    s.text('Konkret heißt: Was genau, wann und womit?', { x: 6.0, y: 4.1, w: 6.6, h: 0.5, size: 20, color: COL.muted }, { fx: 'fade', a: true });
    s.text('Nicht „Videos gucken“, sondern „abends 20 Minuten Lernvideos zu einem Themenblock“.', { x: 6.0, y: 4.65, w: 6.6, h: 0.85, size: 17, italic: true, color: COL.muted }, { fx: 'fade', a: true });
    s.img(I.clock, { x: 6.0, y: 5.75, w: 0.85, h: 0.85 }, { fx: 'zoom', c: true, dur: 400 });
    s.text('15 MIN', { x: 7.0, y: 5.6, w: 4, h: 1.1, font: SERIF, size: 60, bold: true, color: COL.orange, glow: 12, glowOp: 0.4 }, { fx: 'stamp', a: true, dur: 420 });
  }

  // ============ 20 · LERN-WERKZEUGKASTEN ============
  {
    const s = deck.add({ bg: 'bg_center.jpg', transition: 'fade', notes: `
Auflösung. Jede Gruppe stellt ihre drei Tipps vor, du sammelst sie hier ein.
🖱 Klick 1 · Sehen: Lernvideos und Bildfragen, eigene Skizzen, mit Farben markieren, Karteikarten und Zusammenfassungen.
🖱 Klick 2 · Hören: laut vorlesen, sich gegenseitig erklären, Erklär-Videos hören.
🖱 Klick 3 · Machen: mit Fahrstunden verbinden, Situationen nachstellen, beim Lernen bewegen.
🖱 Klick 4 · Kernbotschaft: Am besten kombiniert man mehrere Kanäle. Jeder nimmt sich aus dem Werkzeugkasten, was zu ihm passt.` });
    footer(s);
    kicker(s, 'Eure Ergebnisse', 0.8, 0.9);
    title(s, 'Der Lern-Werkzeugkasten', 0.75, 1.3, 12, 1.0, { size: 44 });
    const b = [[I.eye, 'Sehen', ['Lernvideos & Bildfragen', 'Eigene Skizzen, mit Farben markieren', 'Karteikarten & Zusammenfassungen']],
      [I.ear, 'Hören', ['Laut vorlesen', 'Sich gegenseitig erklären', 'Erklär-Videos hören']],
      [I.hand, 'Machen', ['Mit Fahrstunden verbinden', 'Situationen nachstellen', 'Beim Lernen bewegen']]];
    const cw = 3.7, gap = 0.3, x0 = (W - (3 * cw + 2 * gap)) / 2;
    b.forEach(([ic, t, list], i) => {
      const x = x0 + i * (cw + gap);
      s.rrect(x, 2.55, cw, 3.5, { fill: COL.card, line: '2A3342', rr: 0.14, shadow: true }, { fx: 'rise', c: true, dur: 650 });
      s.img(ic, { x: x + 0.35, y: 2.8, w: 0.6, h: 0.6 }, { fx: 'zoom', a: true, dur: 350 });
      s.text(t, { x: x + 1.1, y: 2.78, w: cw - 1.3, h: 0.65, font: SERIF, size: 30, bold: true, valign: 'middle' }, { fx: 'fade', dur: 350 });
      s.text(list.map((l, j) => ({ text: l, options: { bullet: { code: '25B8' }, breakLine: j < list.length - 1 } })), { x: x + 0.35, y: 3.65, w: cw - 0.6, h: 2.2, size: 18, color: COL.txt, psa: 8 }, { fx: 'fade', dur: 400 });
    });
    s.text([run('Am stärksten: '), run('mehrere Kanäle kombinieren.', { color: COL.orange })], { x: 0.8, y: 6.3, w: 11.7, h: 0.6, font: SERIF, size: 28, bold: true, align: 'center' }, { fx: 'rise', c: true, dur: 700 });
  }

  // ============ 21 · BRÜCKE ============
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
Jetzt weißt du, wie du lernst.
🖱 1 Klick: Aber wer sorgt dafür, dass du auf Kurs bleibst? Kurze Pause.
➜ Überleitung: Damit ihr das nicht allein durchziehen müsst, habe ich etwas gebaut.` });
    title(s, 'Jetzt weißt du, wie du lernst.', 0.8, 2.3, 11.7, 1.1, { size: 54, align: 'center' }, { fx: 'fade', auto: true, dur: 1200 });
    s.text('Aber wer sorgt dafür, dass du auf Kurs bleibst?', { x: 0.8, y: 3.75, w: 11.7, h: 0.9, font: SERIF, size: 38, italic: true, color: COL.orange, align: 'center' }, { fx: 'rise', c: true, dur: 1000 });
  }

  // ============ 22 · ZWEI APPS ============
  {
    const s = deck.add({ bg: 'bg_bokeh.jpg', transition: 'fade', notes: `
Der große Moment. Ruhig und stolz, nicht angeben:
„Für die perfekte Ausbildung von euch habe ich zwei Apps gebaut.“
🖱 Klick 1: Der Fahrlehrer-Kompass. Er weiß, wie du tickst und wo du stehst.
🖱 Klick 2: Die Fahr-Akademie. Du kennst die Prüfung, bevor du sie fährst.
➜ Wir schauen uns beide an. Zuerst der Kompass.` });
    footer(s);
    kicker(s, 'Für eure Ausbildung', 0.8, 0.9, { align: 'center', w: 11.7 });
    title(s, 'Ich habe zwei Apps gebaut.', 0.8, 1.3, 11.7, 1.0, { size: 50, align: 'center' }, { fx: 'fade', auto: true, dur: 1000 });
    s.img('phone_kompass.png', { x: 0.9, y: 2.5, w: 3.0, h: 3.0 * 1469 / 1014 }, { fx: 'flyL', c: true, dur: 1000 });
    s.text('Fahrlehrer-\nKompass', { x: 3.95, y: 3.5, w: 2.6, h: 1.1, font: SERIF, size: 28, bold: true, color: COL.kGold }, { fx: 'fade', a: true });
    s.text('Ich weiß, wie du tickst\nund wo du stehst.', { x: 3.95, y: 4.65, w: 2.6, h: 1.0, size: 17, color: COL.muted }, { fx: 'fade' });
    s.img('tablet_akademie.png', { x: 9.2, y: 2.5, w: 3.3, h: 3.3 * 1364 / 1058 }, { fx: 'flyR', c: true, dur: 1000 });
    s.text('Fahr-\nAkademie', { x: 6.55, y: 3.5, w: 2.5, h: 1.1, font: SERIF, size: 28, bold: true, color: COL.aGold, align: 'right' }, { fx: 'fade', a: true });
    s.text('Du kennst die Prüfung,\nbevor du sie fährst.', { x: 6.45, y: 4.65, w: 2.6, h: 1.0, size: 17, color: COL.muted, align: 'right' }, { fx: 'fade' });
  }

  // ============ 23 · KOMPASS INTRO ============
  {
    const s = deck.add({ bg: 'bg_green.jpg', transition: 'black', notes: `
Das Schülerprofil im Fahrlehrer-Kompass. Alles an einem Ort, nur was dich als Schüler betrifft.
➜ Drei Dinge: Wie du tickst. Wo du stehst. Wann du bereit bist.` });
    footer(s);
    s.img(I.compass, { x: 0.8, y: 1.2, w: 1.1, h: 1.1 }, { fx: 'zoom', auto: true, dur: 800 });
    kicker(s, 'App 1', 0.8, 2.6, { color: COL.kGold });
    title(s, 'Fahrlehrer-Kompass', 0.75, 3.0, 8.7, 1.2, { size: 54, color: COL.txt }, { fx: 'rise', auto: true, a: true, dur: 1000 });
    s.text('Ich weiß, wie du tickst. Und wo du stehst.', { x: 0.8, y: 4.3, w: 8, h: 0.7, font: SERIF, size: 30, italic: true, color: COL.kGold }, { fx: 'fade', auto: true, a: true });
    ['Wie du tickst', 'Wo du stehst', 'Wann du bereit bist'].forEach((t, i) => chip(s, t, 0.8 + i * 2.95, 5.5, 2.75, { size: 17, fill: '12201A', line: '2E5A40' }, { fx: 'rise', auto: true, a: true, dur: 450 }));
    phone(s, 'k_plan.jpg', 9.6, 0.9, 2.75, { frame: '2E5A40' }, { fx: 'rise', auto: true, dur: 1100 });
  }

  // ============ 24 · FARBPROFIL ============
  {
    const s = deck.add({ bg: 'bg_green.jpg', transition: 'fade', notes: `
Jeder Schüler bei mir füllt einen Persönlichkeitsbogen aus. 65 Fragen. Daraus entsteht dein Farbprofil und deine Lernkanäle.
Der Kurzcheck eben war der Einstieg. Der Bogen geht viel tiefer.
🖱 4 Klicks, je eine Farbe: Rot, der Macher. Gelb, der Begeisterte. Grün, der Ruhige. Blau, der Gründliche.
Wichtig: Das ist kein Urteil über dich. Es hilft mir, dich so zu unterrichten, wie du tickst. Ruhige Schüler brauchen etwas anderes als Macher.` });
    footer(s);
    kicker(s, 'Wie du tickst', 0.8, 0.9, { color: COL.kGold });
    title(s, 'Dein Farbprofil', 0.75, 1.3, 6, 1.0, { size: 48 });
    s.text('Persönlichkeitsbogen mit 65 Fragen: dein Farbprofil und deine Lernkanäle.', { x: 0.8, y: 2.3, w: 5.4, h: 0.9, size: 19, color: COL.muted }, { fx: 'fade', auto: true });
    phone(s, 'k_farbprofil.jpg', 6.35, 0.8, 2.85, { frame: '2E5A40' }, { fx: 'rise', auto: true, a: true, dur: 900 });
    const cols = [['CF5A48', 'Rot', 'Der Macher'], ['CF9A3E', 'Gelb', 'Der Begeisterte'], ['4CAF72', 'Grün', 'Der Ruhige'], ['2F7DD1', 'Blau', 'Der Gründliche']];
    cols.forEach(([c, n, t], i) => {
      const y = 3.35 + i * 0.85;
      s.rrect(0.8, y, 5.3, 0.7, { fill: '10181A', line: c, lw: 1.5, rr: 0.18 }, { fx: 'flyL', c: true, dur: 600 });
      s.oval(1.0, y + 0.14, 0.42, 0.42, { fill: c, glow: 8, glowColor: c, glowOp: 0.5 }, { fx: 'zoom', dur: 400 });
      s.text(n, { x: 1.6, y: y + 0.1, w: 1.4, h: 0.5, size: 20, bold: true, valign: 'middle' }, { fx: 'fade', dur: 400 });
      s.text(t, { x: 3.0, y: y + 0.1, w: 3.0, h: 0.5, font: SERIF, size: 21, italic: true, color: COL.muted, valign: 'middle' }, { fx: 'fade', dur: 400 });
    });
    s.text('Damit ich dich so unterrichte, wie du tickst.', { x: 9.6, y: 3.2, w: 3.3, h: 1.6, font: SERIF, size: 26, italic: true, color: COL.kGold }, { fx: 'fade', c: true, dur: 900 });
  }

  // ============ 25 · AUSBILDUNGSPLAN (Treppe) ============
  {
    const s = deck.add({ bg: 'bg_green.jpg', transition: 'fade', notes: `
Der Ausbildungsplan. Damit dich die neue Freiheit nicht überrollt, bekommst du Struktur, Schritt für Schritt bis zur Prüfung.
🖱 Klick: Die sechs Stufen bauen sich als Treppe auf:
01 Grundstufe (8 Punkte), 02 Aufbaustufe (7), 03 Leistungsstufe (9), 04 Sonderfahrten (Überland, Autobahn, Nacht), 05 Grundfahraufgaben (6), 06 Technik und Abfahrtkontrolle.
Jeder Punkt hat eine Ampel: Rot fehlt noch, Gelb in Arbeit, Grün geschafft. Du siehst jederzeit, wo du stehst und was noch fehlt.` });
    footer(s);
    kicker(s, 'Wo du stehst', 0.8, 0.9, { color: COL.kGold });
    title(s, 'Dein Ausbildungsplan', 0.75, 1.3, 7, 1.0, { size: 48 });
    const st = [['01', 'Grundstufe', '8 Punkte'], ['02', 'Aufbaustufe', '7 Punkte'], ['03', 'Leistungsstufe', '9 Punkte'], ['04', 'Sonderfahrten', 'Überland · Autobahn · Nacht'], ['05', 'Grundfahr-\naufgaben', '6 Aufgaben'], ['06', 'Technik &\nAbfahrt-\nkontrolle', 'Checkliste']];
    const tw = 1.87, gap = 0.1, x0 = 0.8;
    st.forEach(([n, t, sub], i) => {
      const x = x0 + i * (tw + gap), h = 2.0 + i * 0.38, y = 6.75 - h;
      s.rrect(x, y, tw, h, { fill: i < 3 ? '12241B' : '172A20', line: '2E5A40', rr: 0.1, shadow: true }, { fx: 'flyB', c: i === 0, a: i > 0, dur: 650 });
      s.text(n, { x: x + 0.18, y: y + 0.12, w: 1, h: 0.45, size: 18, bold: true, color: COL.kGold }, { fx: 'fade', dur: 300 });
      s.text(t, { x: x + 0.18, y: y + 0.5, w: tw - 0.25, h: 0.9, font: SERIF, size: 16, bold: true }, { fx: 'fade', dur: 300 });
      s.text(sub, { x: x + 0.18, y: y + h - 0.9, w: tw - 0.3, h: 0.45, size: 12, color: COL.muted }, { fx: 'fade', dur: 300 });
      ['CF5A48', 'CF9A3E', '4CAF72'].forEach((c, j) => s.oval(x + 0.18 + j * 0.34, y + h - 0.42, 0.24, 0.24, { fill: c, glow: 5, glowColor: c, glowOp: 0.5 }, { fx: 'zoom', dur: 250 }));
    });
    s.text([run('Rot', { color: 'CF5A48', bold: true }), run(' fehlt noch   ·   '), run('Gelb', { color: 'CF9A3E', bold: true }), run(' in Arbeit   ·   '), run('Grün', { color: '4CAF72', bold: true }), run(' geschafft')], { x: 7.3, y: 1.55, w: 5.4, h: 0.5, size: 17, color: COL.muted, align: 'right' }, { fx: 'fade', c: true });
  }

  // ============ 26 · AMPEL-DETAIL AUFBAUSTUFE ============
  {
    const s = deck.add({ bg: 'bg_green.jpg', transition: 'fade', notes: `
Beispiel Aufbaustufe. Jeder Punkt hat seine Ampel.
🖱 Klick 1: Die Punkte werden nacheinander grün. So fühlt sich Fortschritt an.
🖱 Klick 2: Ein Punkt ist noch gelb: doppelspuriges Abbiegen. Genau da setzen wir in der nächsten Fahrstunde an.
➜ Und jetzt das Beste: Genau an diesem Punkt gibt es einen Knopf …` });
    footer(s);
    kicker(s, 'Jeder Punkt hat seine Ampel', 0.8, 0.9, { color: COL.kGold });
    title(s, '02 · Aufbaustufe', 0.75, 1.3, 7, 1.0, { size: 44 });
    phone(s, 'k_aufbaustufe.jpg', 9.55, 0.8, 2.85, { frame: '2E5A40' }, { fx: 'rise', auto: true, dur: 900 });
    const items = ['Stadtverkehr', '30er-Zone / Rechts vor Links', 'Pfeil-Ampel & Grünpfeil', 'Einbahnstraße', 'Berganfahren', 'Fahrstreifenwechsel mit Schulterblick', 'Doppelspuriges Abbiegen'];
    items.forEach((t, i) => {
      const y = 2.4 + i * 0.62, last = i === 6;
      s.rrect(0.8, y, 8.3, 0.52, { fill: last ? '1C2A20' : '0F1A15', line: last ? COL.kGold : '22382C', lw: last ? 1.5 : 1, rr: 0.12, name: last ? 'rowLast' : undefined }, { fx: 'fade', auto: true, a: i > 0, dur: 180 });
      s.text(t, { x: 1.05, y: y + 0.04, w: 5.6, h: 0.44, size: 18, bold: last, valign: 'middle' }, { fx: 'fade', auto: true, dur: 180 });
      ['CF5A48', 'CF9A3E', '4CAF72'].forEach((c, j) => s.oval(7.45 + j * 0.5, y + 0.1, 0.32, 0.32, { line: c, lw: 1.5, fill: '0B120F' }, { fx: 'fade', auto: true, dur: 180 }));
      const fillCol = last ? 'CF9A3E' : '4CAF72', jx = last ? 1 : 2;
      s.oval(7.45 + jx * 0.5, y + 0.1, 0.32, 0.32, { fill: fillCol, glow: 7, glowColor: fillCol, glowOp: 0.6 }, { fx: 'zoom', c: i === 0 || last, a: i > 0 && !last, dur: 260 });
    });
  }

  // ============ 27 · KEINER ZU VIEL, KEINER ZU WENIG ============
  {
    const s = deck.add({ bg: 'bg_green.jpg', transition: 'fade', notes: `
Wann du bereit bist. Keiner fährt zu viel, keiner zu wenig. Das ist mir wichtig, weil es um euer Geld und eure Sicherheit geht.
Der Ausbildungsstand in Prozent rechnet sich aus deinen Ampeln (Grün zählt voll, Gelb halb) und der Theorieprüfung.
🖱 3 Klicks: der Freigabe-Check. Mindestens 90 % Ausbildungsstand. Alle 12 Sonderfahrten (5 Überland, 4 Autobahn, 3 Nacht). Theorieprüfung bestanden.
🖱 4. Klick: Erst wenn alles grün ist: Bereit für die Prüfung.
Dazu rechnet die App aus, wie viele Fahrstunden du voraussichtlich noch brauchst.
Die Erstversuchsquote meiner Schüler ist echt und wird laufend in der App verfolgt. Nicht angeben, einfach ruhig zeigen. (Vor dem Einsatz prüfen, ob die Zahl noch stimmt.)` });
    footer(s);
    kicker(s, 'Wann du bereit bist', 0.8, 0.9, { color: COL.kGold });
    title(s, 'Keiner fährt zu viel.\nKeiner zu wenig.', 0.75, 1.3, 7.5, 1.8, { size: 46 });
    s.text('90 %', { x: 0.8, y: 3.35, w: 3.6, h: 1.4, font: SERIF, size: 96, bold: true, color: '4CAF72', glow: 14, glowColor: '4CAF72', glowOp: 0.35 }, { fx: 'stamp', auto: true, dur: 450 });
    s.text('Ausbildungsstand\nals Ziellinie', { x: 0.85, y: 4.8, w: 3.4, h: 0.9, size: 18, color: COL.muted }, { fx: 'fade', auto: true, a: true });
    const checks = ['Ausbildungsstand mindestens 90 %', 'Sonderfahrten 12 von 12', 'Theorieprüfung bestanden'];
    checks.forEach((t, i) => {
      const y = 3.4 + i * 0.85;
      s.rrect(4.7, y, 7.8, 0.68, { fill: '10181A', line: '2E5A40', rr: 0.16 }, { fx: 'flyR', c: true, dur: 550 });
      s.img(I.checkK, { x: 4.9, y: y + 0.12, w: 0.44, h: 0.44 }, { fx: 'stamp', a: true, dur: 320 });
      s.text(t, { x: 5.55, y: y + 0.08, w: 6.8, h: 0.52, size: 21, bold: true, valign: 'middle' }, { fx: 'fade', dur: 300 });
    });
    s.text('BEREIT FÜR DIE PRÜFUNG ✓', { x: 5.4, y: 6.05, w: 6.4, h: 0.8, size: 30, bold: true, color: '07140D', fill: '4CAF72', shape: pres.shapes.ROUNDED_RECTANGLE, rr: 0.2, align: 'center', valign: 'middle', rotate: -3, glow: 16, glowColor: '4CAF72', glowOp: 0.45 }, { fx: 'stamp', c: true, dur: 450 });
    s.text('+ Prognose: wie viele Fahrstunden du voraussichtlich noch brauchst', { x: 0.85, y: 5.9, w: 4.2, h: 0.9, size: 15, italic: true, color: COL.kGold }, { fx: 'fade', a: true });
  }

  // ============ 28 · DER KNOPF (Brücke zur Akademie) ============
  {
    const s = deck.add({ bg: 'bg_green.jpg', transition: 'fade', notes: `
Zurück zum gelben Punkt: doppelspuriges Abbiegen. Neben jedem Punkt im Plan sitzt ein grüner Play-Knopf.
Ein Tipp darauf, und du landest direkt im passenden Kapitel der Fahr-Akademie.
🖱 Der Knopf pulsiert. Dann weiterklicken: Wir tauchen rein.` });
    footer(s);
    kicker(s, 'Die Brücke', 0.8, 0.9, { color: COL.kGold });
    title(s, 'Ein Tipp. Und du bist\nmittendrin.', 0.75, 1.3, 11, 1.8, { size: 46 });
    s.rrect(0.8, 3.7, 11.7, 1.3, { fill: '1C2A20', line: COL.kGold, lw: 2, rr: 0.2, shadow: true }, { fx: 'rise', auto: true, dur: 800 });
    s.text('Doppelspuriges Abbiegen', { x: 1.2, y: 3.85, w: 6.5, h: 1.0, font: SERIF, size: 34, bold: true, valign: 'middle' }, { fx: 'fade', auto: true });
    ['CF5A48', 'CF9A3E', '4CAF72'].forEach((c, j) => s.oval(7.9 + j * 0.62, 4.15, 0.4, 0.4, j === 1 ? { fill: c, glow: 7, glowColor: c, glowOp: 0.6 } : { line: c, lw: 1.5, fill: '0B120F' }, { fx: 'fade', auto: true, dur: 200 }));
    s.oval(10.85, 3.87, 0.96, 0.96, { fill: '4CAF72', glow: 18, glowColor: '4CAF72', glowOp: 0.6, name: '!!go' }, [{ fx: 'zoom', auto: true, a: true, dur: 500 }, { fx: 'pulse', auto: true, a: true, loop: true, dur: 700, scale: 118000 }]);
    s.img(I.play, { x: 11.13, y: 4.13, w: 0.44, h: 0.44, name: '!!gopl' }, { fx: 'fade', auto: true, dur: 300 });
    s.text('Video in der Fahr-Akademie ansehen', { x: 7.9, y: 5.25, w: 4.6, h: 0.45, size: 17, color: COL.kGold, align: 'right' }, { fx: 'fade', auto: true, a: true });
  }

  // ============ 29 · AKADEMIE INTRO (Morph: Knopf füllt den Raum) ============
  {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'morph', dur: 1500, notes: `
Und dann habe ich noch mehr gebaut: die Fahr-Akademie.
Nebenbei erwähnen: Die Akademie gibt es auch auf Türkisch, Englisch und Arabisch.
Die Prüfungsstrecke schon kennen, bevor du sie fährst.
➜ Das Herzstück zuerst: Verkehr verstehen, in echtem 3D.` });
    s.oval(-6, -9.5, 25.3, 25.3, { fill: '0E0F0C', name: '!!go' });
    s.img(I.play, { x: 6.45, y: 3.55, w: 0.44, h: 0.44, name: '!!gopl', transparency: 100 });
    footer(s);
    s.img(I.film, { x: 0.8, y: 1.2, w: 1.1, h: 1.1 }, { fx: 'zoom', auto: true, dur: 700 });
    kicker(s, 'App 2', 0.8, 2.6, { color: COL.aGold });
    title(s, 'Fahr-Akademie', 0.75, 3.0, 8, 1.2, { size: 64 }, { fx: 'rise', auto: true, a: true, dur: 1000 });
    s.text('Du kennst die Prüfung, bevor du sie fährst.', { x: 0.8, y: 4.3, w: 8, h: 0.7, font: SERIF, size: 30, italic: true, color: COL.aGold }, { fx: 'fade', auto: true, a: true });
    ['Verkehr in 3D', 'Prüfungsstrecken', '4 Sprachen'].forEach((t, i) => chip(s, t, 0.8 + i * 2.95, 5.5, 2.75, { size: 17, fill: '1E1A12', line: '5A4526' }, { fx: 'rise', auto: true, a: true, dur: 450 }));
    s.text('Auch auf Türkisch, Englisch und Arabisch.', { x: 0.8, y: 6.2, w: 8.5, h: 0.4, size: 17, italic: true, color: COL.muted }, { fx: 'fade', auto: true, a: true });
  }

  // ============ 30 · VERKEHR VERSTEHEN (3D-Video) ============
  const vid = (s, file, x, y, w, anim) => {
    const h = w * 750 / 1200;
    s.rrect(x - 0.08, y - 0.08, w + 0.16, h + 0.16, { fill: '1B1914', line: '5A4526', lw: 1.5, rr: 0.05, shadow: true, glow: 18, glowColor: 'D9954C', glowOp: 0.18 }, anim);
    if (hasMedia(file + '.mp4')) s.video(file + '.mp4', { x, y, w, h, cover: file + '_cover.jpg', loop: true, mute: true, dur: 15000 });
    else s.text('[' + file + ']', { x, y, w, h, fill: '222222', align: 'center', valign: 'middle' });
    return h;
  };
  {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'fade', notes: `
Verkehr verstehen: 22 typische Situationen als echte 3D-Szene. Anschauen, anhalten, aus jedem Blickwinkel. Jede Szene erklärt Schritt für Schritt, was gilt und warum.
Das Video läuft von selbst in Schleife: doppelspuriges Linksabbiegen, genau der Punkt von eben. Die Fahrschule bleibt in ihrer Spur.
❓ Frage: In welche Spur biegt die Fahrschule ein? ✅ In die rechte Spur der Zielstraße. Jeder bleibt in seiner Spur (Pfeile Zeichen 297; ein Spurwechsel ist nur nach § 7 Abs. 5 StVO erlaubt, also mit Rückschau und ohne Gefährdung).` });
    footer(s);
    kicker(s, 'Verkehr verstehen', 0.8, 0.9, { color: COL.aGold });
    title(s, '22 Situationen\nin echtem 3D', 0.75, 1.3, 3.9, 2.0, { size: 40 });
    s.text('Anschauen. Anhalten.\nAus jedem Blickwinkel.', { x: 0.8, y: 3.5, w: 3.6, h: 1.0, size: 20, color: COL.muted }, { fx: 'fade', auto: true });
    s.text('Jede Szene erklärt Schritt für Schritt, was gilt und warum.', { x: 0.8, y: 4.7, w: 3.5, h: 1.2, font: SERIF, size: 20, italic: true, color: COL.aGold }, { fx: 'fade', auto: true, a: true });
    vid(s, 'c_doppel', 4.75, 1.35, 7.9, { fx: 'grow', auto: true, dur: 900 });
  }
  // ============ 31 · BLICKWINKEL ============
  {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'fade', notes: `
Vier Blickwinkel: Übersicht, Folgen, von Oben und aus der Fahrersicht. Hier: der Kreisverkehr von oben.
Bei ½ Tempo kannst du jede Bewegung genau verfolgen.` });
    footer(s);
    kicker(s, 'Aus jedem Blickwinkel', 0.8, 0.9, { color: COL.aGold });
    title(s, 'Von oben.\nVon hinten.\nAus deinen Augen.', 0.75, 1.3, 3.9, 2.8, { size: 38 });
    ['Übersicht', 'Folgen', 'Oben', 'Fahrer'].forEach((t, i) => chip(s, t, 0.8, 4.3 + i * 0.6, 2.4, { size: 16, fill: t === 'Oben' ? 'D9954C' : '1E1A12', color: t === 'Oben' ? '1A140B' : COL.txt, line: '5A4526' }, { fx: 'flyL', auto: true, a: true, dur: 380 }));
    vid(s, 'c_kreisel', 4.75, 1.35, 7.9, { fx: 'grow', auto: true, dur: 900 });
  }
  // ============ 32 · TAG UND NACHT ============
  {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'fade', notes: `
Jede Szene gibt es bei Tag, in der Dämmerung und bei Nacht. Hier die Rettungsgasse auf der Autobahn bei Nacht.
❓ Frage: Wo bildet ihr die Rettungsgasse bei drei Fahrstreifen? ✅ Zwischen dem ganz linken und dem mittleren Fahrstreifen (§ 11 Abs. 2 StVO).` });
    footer(s);
    kicker(s, 'Tag · Dämmerung · Nacht', 0.8, 0.9, { color: COL.aGold });
    title(s, 'Auch bei\nNacht.', 0.75, 1.3, 3.9, 2.0, { size: 44 });
    s.img(I.sun, { x: 0.8, y: 3.6, w: 0.6, h: 0.6 }, { fx: 'zoom', auto: true, dur: 300 });
    s.img(I.moon, { x: 1.6, y: 3.6, w: 0.6, h: 0.6 }, { fx: 'zoom', auto: true, a: true, dur: 300 });
    s.text('Rettungsgasse auf der Autobahn, bei Nacht.', { x: 0.8, y: 4.45, w: 3.6, h: 1.0, size: 20, color: COL.muted }, { fx: 'fade', auto: true, a: true });
    vid(s, 'c_nacht', 4.75, 1.35, 7.9, { fx: 'grow', auto: true, dur: 900 });
  }
  // ============ 33 · FAHRERSICHT ============
  if (hasMedia('c_fahrer.mp4')) {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'fade', notes: `
Die Fahrersicht: Du sitzt selbst am Steuer und siehst, was der Fahrer sieht. Hier: Fußgängerüberweg.
❓ Frage: Was gilt am Zebrastreifen? ✅ Fußgängern das Überqueren ermöglichen, nur mit mäßiger Geschwindigkeit heranfahren, wenn nötig warten (§ 26 StVO).` });
    footer(s);
    kicker(s, 'Fahrersicht', 0.8, 0.9, { color: COL.aGold });
    title(s, 'Du sitzt\nam Steuer.', 0.75, 1.3, 3.9, 2.0, { size: 44 });
    s.text('Fußgängerüberweg (Zeichen 350) aus der Sicht des Fahrers.', { x: 0.8, y: 3.6, w: 3.6, h: 1.0, size: 20, color: COL.muted }, { fx: 'fade', auto: true });
    vid(s, 'c_fahrer', 4.75, 1.35, 7.9, { fx: 'grow', auto: true, dur: 900 });
  }
  // ============ 34 · MITDENKEN ============
  if (hasArt('mitdenken_frage.jpg')) {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'fade', notes: `
Mitdenken: Die Szene hält bei einer Frage an. Erst selbst überlegen, dann Auflösung zeigen.
Wichtig: keine Noten, kein Rot und Grün, nichts wird gespeichert. Nur für dich.
🖱 1 Klick: die Auflösung erscheint.` });
    footer(s);
    kicker(s, 'Mitdenken', 0.8, 0.9, { color: COL.aGold });
    title(s, 'Die Szene hält an.\nDu denkst mit.', 0.75, 1.3, 5.6, 2.0, { size: 40 });
    s.text('Keine Noten. Nichts wird gespeichert.\nNur für dich.', { x: 0.8, y: 3.55, w: 5.4, h: 1.0, size: 19, color: COL.muted }, { fx: 'fade', auto: true });
    const ih = 5.75, iw = ih * 1510 / 1573;
    s.img('mitdenken_frage.jpg', { x: 12.55 - iw, y: 1.05, w: iw, h: ih, shadow: true, name: 'md1' }, { fx: 'grow', auto: true, dur: 800 });
    if (hasArt('mitdenken_aufl.jpg')) s.img('mitdenken_aufl.jpg', { x: 12.55 - iw, y: 1.05, w: iw, h: ih, shadow: true }, { fx: 'fade', c: true, dur: 600 });
    s.text([run('Richtig ist A. ', { bold: true, color: COL.aGold }), run('Links bleibt links, rechts bleibt rechts.')], { x: 0.8, y: 4.9, w: 5.4, h: 1.0, size: 20 }, { fx: 'fade', a: true });
  }
  // ============ 35 · 22 SZENEN ============
  {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'fade', notes: `
Alle 22 Szenen auf einen Blick, in vier Bereichen. Genau die Situationen, die in der Prüfung drankommen.
🖱 Baut sich von selbst auf.` });
    footer(s);
    kicker(s, 'Alle Szenen', 0.8, 0.9, { color: COL.aGold });
    title(s, 'Die Situationen, die in der Prüfung drankommen', 0.75, 1.3, 12, 1.0, { size: 36 });
    const cats = [['Innerorts', ['Rechts vor links', 'Linksabbiegen mit Gegenverkehr', 'Zwei Linksabbieger', 'Rechtsabbiegen mit Radweg', 'Doppelspuriges Abbiegen', 'Kreisverkehr', 'Zebrastreifen', 'Engstelle', 'Stoppschild', 'Grünpfeil', 'Schulbus mit Warnblinklicht']],
      ['Landstraße', ['Überholen', '(richtig und falsch)']],
      ['Grundfahraufgaben', ['Längs einparken', 'Quer einparken (rückwärts)', 'Quer einparken (vorwärts)', 'Wenden in drei Zügen', 'Rückwärts um die Ecke', 'Gefahrbremsung']],
      ['Autobahn', ['Auffahren', 'Abfahren', 'Reißverschluss', 'Rettungsgasse']]];
    const cw = 2.85, gap = 0.17, x0 = (W - (4 * cw + 3 * gap)) / 2;
    cats.forEach(([c, list], i) => {
      const x = x0 + i * (cw + gap);
      s.rrect(x, 2.45, cw, 0.95 + list.length * 0.285, { fill: '14130F', line: '4A3B24', rr: 0.1 }, { fx: 'rise', auto: true, a: i > 0, dur: 500 });
      s.text(c, { x: x + 0.2, y: 2.6, w: cw - 0.3, h: 0.5, font: SERIF, size: 19, bold: true, color: COL.aGold }, { fx: 'fade', auto: true, dur: 300 });
      s.text(list.map((l, j) => ({ text: l, options: { breakLine: j < list.length - 1 } })), { x: x + 0.2, y: 3.15, w: cw - 0.3, h: 3.55, size: 14.5, color: COL.txt, lsm: 1.05 }, { fx: 'fade', auto: true, dur: 300 });
    });
  }
  // ============ 36 · VIDEOS & PRÜFUNGSSTRECKEN ============
  {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'fade', notes: `
Dazu die Videos: Videoaufnahmen von fast allen Prüfungsstrecken in Offenbach, sortiert nach Prüfer. Fast jeder Prüfer, den wir hier haben, einmal erklärt.
Dazu echte Prüfungsfahrten, bestanden und nicht bestanden, mit Markierung „Hier lag der Fehler“. Und Lernvideos nach Themen: Stoppschilder, Vorfahrt, rechts vor links und mehr.
🖱 3 Klicks: je ein Punkt.` });
    footer(s);
    kicker(s, 'Die Videos', 0.8, 0.9, { color: COL.aGold });
    title(s, 'Die Prüfungsstrecke kennen,\nbevor du sie fährst', 0.75, 1.3, 12, 1.7, { size: 40 });
    s.img('a_videos.jpg', { x: 0.8, y: 3.2, w: 6.4, h: 6.4 * 887 / 1774, shadow: true }, { fx: 'grow', auto: true, dur: 800 });
    const pts = [[I.route, 'Prüfungsstrecken, sortiert nach Prüfer'], [I.film, 'Echte Prüfungsfahrten mit „Hier lag der Fehler“'], [I.cam, 'Lernvideos nach Themen und Situationen']];
    pts.forEach(([ic, t], i) => {
      const y = 3.3 + i * 1.05;
      s.img(ic, { x: 7.6, y, w: 0.6, h: 0.6 }, { fx: 'zoom', c: true, dur: 350 });
      s.text(t, { x: 8.4, y: y - 0.1, w: 4.3, h: 0.85, size: 20, bold: true, valign: 'middle' }, { fx: 'fade', dur: 350 });
    });
  }
  // ============ 37 · VIER SPRACHEN (gestrichen, nur noch Hinweis auf Folie „Fahr-Akademie“) ============
  if (false) {
    const s = deck.add({ bg: 'bg_gold.jpg', transition: 'fade', notes: `
Die Akademie spricht vier Sprachen: Deutsch, Türkisch, Englisch und Arabisch. Alle Erklärungen, auch in den 3D-Szenen.
Für viele von euch oder eure Eltern ein echtes Argument.` });
    footer(s);
    kicker(s, 'Für alle', 0.8, 0.9, { color: COL.aGold });
    title(s, 'In deiner Sprache', 0.75, 1.3, 6.4, 1.0, { size: 48 });
    const L = [['Deutsch', 'Verkehr verstehen'], ['Türkçe', 'Trafiği anlamak'], ['English', 'Understanding traffic'], ['العربية', 'فهم حركة المرور']];
    L.forEach(([l, t], i) => {
      const y = 2.65 + i * 1.0;
      s.text(l, { x: 0.8, y, w: 3.4, h: 0.85, font: SERIF, size: 40, bold: true, color: i === 0 ? COL.aGold : COL.txt, align: 'left', valign: 'middle' }, { fx: 'flyL', auto: true, a: i > 0, dur: 600 });
      s.text(t, { x: 4.1, y, w: 3.1, h: 0.85, size: 19, italic: true, color: COL.muted, align: 'left', valign: 'middle' }, { fx: 'fade', auto: true, dur: 600 });
    });
    if (hasArt('tr_player.jpg')) { const ih = 5.75, iw = ih * 1510 / 1573; s.img('tr_player.jpg', { x: 12.55 - iw, y: 1.05, w: iw, h: ih, shadow: true }, { fx: 'grow', c: true, dur: 800 }); s.text('Türkçe', { x: 12.55 - iw, y: 6.85, w: iw, h: 0.35, size: 13, color: COL.dim, align: 'center' }, { fx: 'fade' }); }
  }
  // ============ 38 · EIN JAHR ARBEIT ============
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
Ehrlich sagen: Über ein Jahr Arbeit. Strecken abfahren, filmen, schneiden, einsortieren, die Apps drumherum bauen. Das gibt es bei keiner anderen Fahrschule.
🖱 1 Klick: Bitte erzählt es weiter.` });
    title(s, 'Über ein Jahr Arbeit.', 0.8, 1.9, 11.7, 1.2, { size: 64, align: 'center' }, { fx: 'fade', auto: true, dur: 1200 });
    s.text('Strecken abfahren. Filmen. Schneiden. Einsortieren. Zwei Apps bauen.', { x: 0.8, y: 3.25, w: 11.7, h: 0.6, size: 22, color: COL.muted, align: 'center' }, { fx: 'fade', auto: true, a: true });
    s.text('Das gibt es bei keiner anderen Fahrschule.', { x: 0.8, y: 4.35, w: 11.7, h: 0.9, font: SERIF, size: 40, italic: true, color: COL.orange, align: 'center', glow: 10, glowOp: 0.3 }, { fx: 'rise', auto: true, a: true, dur: 1000 });
    s.text('Erzählt es weiter.', { x: 0.8, y: 5.6, w: 11.7, h: 0.6, size: 24, bold: true, cs: 3, align: 'center' }, { fx: 'fade', c: true });
  }

  // ============ 39–42 · EINE LETZTE SACHE (Ballon) ============
  const phoneFrame = (s, x, y, w, h) => {
    s.rrect(x, y, w, h, { line: COL.orange, lw: 5, rr: 0.35, name: '!!pf', glow: 10, glowColor: COL.orange, glowOp: 0.25 });
    s.rrect(x + w / 2 - 0.55, y + 0.05, 1.1, 0.22, { fill: COL.orange, rr: 0.5, name: '!!pn' });
  };
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
ACHTUNG, JETZT KOMMT DER HÖHEPUNKT. VORBEREITUNG VOR DER STUNDE: Luftballon aufpusten und unsichtbar bereitlegen (hinter dem Pult, in der Tasche, hinter dem Rücken). Nadel griffbereit.
Jetzt ruhig werden, Tempo rausnehmen: „Eine letzte Sache. Nehmt bitte euer Handy.“` });
    kicker(s, 'Eine letzte Sache', 0.8, 1.15, { name: '!!k' });
    title(s, 'Nimm dein Handy.', 0.75, 1.55, 5.45, 1.0, { size: 44, name: '!!t' }, { fx: 'fade', auto: true, dur: 1000 });
    phoneFrame(s, 7.4, 1.4, 2.6, 5.2);
  }
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'morph', dur: 1100, footer: false, notes: `
„Öffnet die Notizen-App.“ Warten, bis wirklich alle die App offen haben. Noch nicht schreiben lassen.` });
    kicker(s, 'Eine letzte Sache', 0.8, 1.15, { name: '!!k' });
    title(s, 'Nimm dein Handy.', 0.75, 1.55, 5.45, 1.0, { size: 44, name: '!!t' });
    s.text('Öffne die Notizen-App und schreib auf:', { x: 0.8, y: 2.75, w: 5.4, h: 0.5, size: 20, color: COL.muted, name: '!!sub' });
    phoneFrame(s, 6.3, 0.55, 5.8, 7.6);
  }
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'morph', dur: 1100, footer: false, notes: `
Erste Frage vorlesen: Wer ist der Mensch, der dich am meisten liebt auf der Welt? Noch nicht schreiben lassen, die zweite Frage kommt gleich.` });
    kicker(s, 'Eine letzte Sache', 0.8, 1.15, { name: '!!k' });
    title(s, 'Nimm dein Handy.', 0.75, 1.55, 5.45, 1.0, { size: 44, name: '!!t' });
    s.text('Öffne die Notizen-App und schreib auf:', { x: 0.8, y: 2.75, w: 5.4, h: 0.5, size: 20, color: COL.muted, name: '!!sub' });
    phoneFrame(s, 6.3, 0.55, 5.8, 7.6);
    s.oval(6.75, 2.35, 0.6, 0.6, { fill: '2A1A0E', line: COL.orange, lw: 1.5, name: '!!n1' });
    s.text('1', { x: 6.75, y: 2.35, w: 0.6, h: 0.6, size: 20, bold: true, color: COL.orange, align: 'center', valign: 'middle', name: '!!n1t' });
    s.text('Wer ist der Mensch, der dich am meisten liebt auf der Welt?', { x: 7.55, y: 2.2, w: 4.3, h: 1.4, font: SERIF, size: 28, bold: true, name: '!!f1' });
  }
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'morph', dur: 1100, footer: false, notes: `
Zweite Frage vorlesen: Was ist dein größter Traum?
Dann sagen: „Wenn ich Jetzt sage, schreibt beides auf.“ Dann sagen: „JETZT.“
Warten, bis wirklich alle Köpfe unten sind und konzentriert schreiben. GENAU IN DIESEM MOMENT den Ballon platzen lassen.
Danach die Stille aushalten. Nicht sofort reden. Erst dann weiterklicken.` });
    kicker(s, 'Eine letzte Sache', 0.8, 1.15, { name: '!!k' });
    title(s, 'Nimm dein Handy.', 0.75, 1.55, 5.45, 1.0, { size: 44, name: '!!t' });
    s.text('Öffne die Notizen-App und schreib auf:', { x: 0.8, y: 2.75, w: 5.4, h: 0.5, size: 20, color: COL.muted, name: '!!sub' });
    phoneFrame(s, 6.3, 0.55, 5.8, 7.6);
    s.oval(6.75, 2.35, 0.6, 0.6, { fill: '2A1A0E', line: COL.orange, lw: 1.5, name: '!!n1' });
    s.text('1', { x: 6.75, y: 2.35, w: 0.6, h: 0.6, size: 20, bold: true, color: COL.orange, align: 'center', valign: 'middle', name: '!!n1t' });
    s.text('Wer ist der Mensch, der dich am meisten liebt auf der Welt?', { x: 7.55, y: 2.2, w: 4.3, h: 1.4, font: SERIF, size: 28, bold: true, name: '!!f1' });
    s.oval(6.75, 4.45, 0.6, 0.6, { fill: '2A1A0E', line: COL.orange, lw: 1.5, name: '!!n2' });
    s.text('2', { x: 6.75, y: 4.45, w: 0.6, h: 0.6, size: 20, bold: true, color: COL.orange, align: 'center', valign: 'middle', name: '!!n2t' });
    s.text('Was ist dein größter Traum?', { x: 7.55, y: 4.3, w: 4.3, h: 1.0, font: SERIF, size: 28, bold: true, name: '!!f2' });
  }
  // ============ 43 · NUR EIN BALLON (neu) ============
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
Erst NACH dem Knall und der Stille weiterklicken. Leise sprechen.
„Das war nur ein Ballon.“
🖱 1 Klick: „Auf der Straße ist es keiner.“ Pause. Wirken lassen.` });
    title(s, 'Das war nur ein Ballon.', 0.8, 2.3, 11.7, 1.2, { size: 60, align: 'center' }, { fx: 'fade', auto: true, dur: 1500 });
    s.text('Auf der Straße ist es keiner.', { x: 0.8, y: 3.8, w: 11.7, h: 1.2, font: SERIF, size: 56, bold: true, color: COL.red, align: 'center', glow: 14, glowColor: COL.red, glowOp: 0.35 }, { fx: 'fade', c: true, dur: 1500 });
  }
  // ============ 44–45 · 14 METER ============
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
Jetzt langsam und leise sprechen. 14 Meter fährst du bei Tempo 50 in einer einzigen Sekunde. Jede Sekunde, die ihr aufs Handy schaut, sind 14 Meter Blindflug.` });
    kicker(s, 'Ein Wimpernschlag', 0.8, 0.95, { name: '!!k' });
    s.text([run('14', { fontFace: SERIF, fontSize: 150, bold: true }), run(' METER', { fontFace: SERIF, fontSize: 60, bold: true }), run('.', { fontFace: SERIF, fontSize: 60, bold: true, color: COL.orange })], { x: 0.75, y: 1.3, w: 7.5, h: 2.3, valign: 'bottom', name: '!!m' }, { fx: 'stamp', auto: true, dur: 500 });
    s.text([run('So weit fährst du bei 50 km/h', { breakLine: true }), run('in nur '), run('einer Sekunde.', { color: COL.orange, bold: true })], { x: 0.8, y: 3.8, w: 6.2, h: 1.3, font: SERIF, size: 30, name: '!!s' }, { fx: 'fade', auto: true, a: true, dur: 1000 });
    s.text('50 km/h ÷ 3,6 ≈ 14 m pro Sekunde · vgl. Kampagne „Runter vom Gas“ (BMV/DVR)', { x: 0.8, y: 6.95, w: 9, h: 0.3, size: 12, color: '9AA3AE', name: '!!src' });
  }
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'morph', dur: 1100, footer: false, notes: `
Der Satz, auf den alles hinausläuft. Langsam vorlesen, danach Pause:
Aus dem Menschen, der dich am meisten liebt, kann der werden, der dich am meisten vermisst.
Nicht moralisieren. Wirken lassen.
14 m: 50 km/h ÷ 3,6 = 13,9 m pro Sekunde. Thema Ablenkung: Kampagne „Runter vom Gas“ von BMV und DVR.` });
    kicker(s, 'Ein Wimpernschlag', 0.8, 0.95, { name: '!!k' });
    s.text([run('14', { fontFace: SERIF, fontSize: 150, bold: true }), run(' METER', { fontFace: SERIF, fontSize: 60, bold: true }), run('.', { fontFace: SERIF, fontSize: 60, bold: true, color: COL.orange })], { x: 0.75, y: 1.3, w: 7.5, h: 2.3, valign: 'bottom', name: '!!m' });
    s.text([run('So weit fährst du bei 50 km/h', { breakLine: true }), run('in nur '), run('einer Sekunde.', { color: COL.orange, bold: true })], { x: 0.8, y: 3.8, w: 6.2, h: 1.3, font: SERIF, size: 30, name: '!!s' });
    s.text([run('Aus dem Menschen, der dich am meisten liebt, kann der werden, der dich '), run('am meisten vermisst.', { color: COL.orange })], { x: 7.3, y: 2.2, w: 5.4, h: 4.0, font: SERIF, size: 34, bold: true, lsm: 1.1, valign: 'middle' }, { fx: 'fade', auto: true, dur: 2200, d: 600 });
    s.text('50 km/h ÷ 3,6 ≈ 14 m pro Sekunde · vgl. Kampagne „Runter vom Gas“ (BMV/DVR)', { x: 0.8, y: 6.95, w: 9, h: 0.3, size: 12, color: '9AA3AE', name: '!!src' });
  }
  // ============ 46 · LERNEN HÖRT NIE AUF ============
  {
    const s = deck.add({ bg: 'bg_bokeh.jpg', transition: 'black', footer: false, notes: `
Den Bogen schließen: Lernen hört nie auf. Das war heute unser Thema.
🖱 Klick 1: Und Verantwortung hört auch nie auf. Beides gehört zusammen.
🖱 Klick 2: Die drei Merksätze: Handy weg. Wach bleiben. Weiterlernen.

ABSCHLUSSREDE (ca. 1 Minute, frei sprechen oder vorlesen):
„Ihr habt heute gelernt, wie ihr lernt. Ihr habt gesehen, dass ich euch dabei nicht allein lasse: mit dem Kompass, mit der Akademie, mit jeder Fahrstunde.
Aber eins kann ich euch nicht abnehmen. Wenn ihr in ein paar Monaten allein im Auto sitzt, sitzt keiner mehr neben euch. Dann entscheidet ihr. Jede Sekunde.
Ihr habt vorhin aufgeschrieben, wer euch am meisten liebt und wovon ihr träumt. Genau das fährt jedes Mal mit, wenn ihr einsteigt.
Eine Sekunde aufs Handy sind 14 Meter. 14 Meter, in denen ein Kind auf die Straße laufen kann. 14 Meter, die ihr nie wieder zurückbekommt.
Ich will, dass ihr bestehen. Aber noch mehr will ich, dass ihr ankommt. Jeden Tag. Ein Leben lang.
Handy weg. Wach bleiben. Weiterlernen.“

Bedanken, Fragen einsammeln. Letzter Satz: Denkt an den Knall, wenn ihr das nächste Mal das Handy ins Auto nehmt.` });
    s.text([run('LERNEN', { color: COL.orange }), run('\nhört nie auf.')], { x: 0.8, y: 0.9, w: 6.0, h: 2.4, font: SERIF, size: 50, bold: true, lsm: 0.95 }, { fx: 'rise', auto: true, dur: 1100 });
    s.text([run('VERANTWORTUNG', { color: COL.orange }), run('\nauch nicht.')], { x: 5.9, y: 2.0, w: 6.95, h: 2.4, font: SERIF, size: 50, bold: true, lsm: 0.95, align: 'right' }, { fx: 'rise', c: true, dur: 1100 });
    const m = [[I.ban, 'Handy weg'], [I.eyeW, 'Wach bleiben'], [I.brainO, 'Weiterlernen']];
    const cw = 3.6, gap = 0.45, x0 = (W - (3 * cw + 2 * gap)) / 2;
    m.forEach(([ic, t], i) => {
      const x = x0 + i * (cw + gap);
      s.rrect(x, 5.05, cw, 1.45, { fill: COL.card, line: '3A4455', rr: 0.18, shadow: true }, { fx: 'rise', c: i === 0, a: i > 0, dur: 600 });
      s.img(ic, { x: x + 0.35, y: 5.45, w: 0.65, h: 0.65 }, { fx: 'zoom', dur: 350 });
      s.text(t, { x: x + 1.15, y: 5.3, w: cw - 1.3, h: 0.95, font: SERIF, size: 25, bold: true, valign: 'middle' }, { fx: 'fade', dur: 350 });
    });
  }

  if (ONLY) { /* Testmodus: nur ausgewählte Folien behalten */ }
  const out = path.join(__dirname, 'Lektion12_Lebenslanges_Lernen.pptx');
  await finalize(deck, out);
  console.log('Folien:', deck.slides.length, '·', (fs.statSync(out).size / 1e6).toFixed(2), 'MB');
}
build().catch(e => { console.error(e); process.exit(1); });
