// Arbeitsblätter Gruppenarbeit Lektion 12 (A4, druckfertig) → PDF
const React = require('react');
const RDS = require('react-dom/server');
const LU = require('react-icons/lu');
const fs = require('fs');
const path = require('path');
const ic = (n, c = '#E8650F', s = 28) => RDS.renderToStaticMarkup(React.createElement(LU[n], { color: c, size: String(s), strokeWidth: 1.8 }));

const GROUPS = [
  {
    key: 'sehen', kanal: 'Sehen', typ: 'Der Seher', icon: 'LuEye',
    sub: 'Du nimmst am meisten über die Augen auf.',
    info: 'Du verstehst Dinge am schnellsten, wenn du sie siehst. Eine Skizze, ein kurzes Video oder eine Strecke vorab auf der Karte bringen dir mehr als jede lange Erklärung. Was du einmal vor dir gesehen hast, bleibt bei dir hängen.',
    denk: [
      'Wie könnt ihr euch Verkehrszeichen merken, ohne sie nur zu lesen?',
      'Welche Bilder oder Videos helfen euch bei Vorfahrt und Abbiegen?',
      'Wie könnt ihr eine Strecke „sehen“, bevor ihr sie fahrt?',
      'Was könnt ihr mit Farben, Skizzen oder Karteikarten machen?',
      'Wie wird aus einer Fahrstunde ein Bild, das im Kopf bleibt?'
    ]
  },
  {
    key: 'hoeren', kanal: 'Hören', typ: 'Der Denker', icon: 'LuEar',
    sub: 'Du verstehst über Sprache und Erklärung.',
    info: 'Bei dir festigt sich das Wissen übers Reden und Zuhören. Wenn dir jemand ruhig erklärt, warum etwas so ist, klickt es. Und wenn du es selbst laut aussprichst, sitzt es endgültig.',
    denk: [
      'Mit wem könnt ihr über Theoriefragen sprechen, und wann?',
      'Wie könnt ihr beim Fahren (oder als Beifahrer) laut mitdenken?',
      'Wie könnt ihr euch den Stoff unterwegs anhören?',
      'Wem könnt ihr eine Regel so erklären, dass er sie versteht?',
      'Welche „Warum“-Fragen stellt ihr eurem Fahrlehrer?'
    ]
  },
  {
    key: 'machen', kanal: 'Machen', typ: 'Der Macher', icon: 'LuHand',
    sub: 'Du lernst im Tun, nicht in der Theorie.',
    info: 'Lange Erklärungen bringen dir wenig. Du verstehst es, sobald du selbst am Steuer sitzt. Wiederholen und Ausprobieren ist bei dir der schnellste Weg, und Fehler sind für dich eher Übung als Rückschlag.',
    denk: [
      'Wie könnt ihr eine Kreuzung zu Hause nachstellen (Papier, Spielzeugautos, Handy)?',
      'Wie verbindet ihr die Theorie mit der nächsten Fahrstunde?',
      'Wie könnt ihr in Bewegung lernen, statt still am Schreibtisch?',
      'Wie könnt ihr als Beifahrer üben, ohne selbst zu fahren?',
      'Wie macht ihr aus Theoriefragen ein Spiel oder einen Wettkampf?'
    ]
  }
];

const IDEEN = {
  sehen: ['Abends 20 Min. Lernvideos zu einem Themenblock, danach 5 Bildfragen im Fragenkatalog.', 'Vor jeder Fahrstunde 5 Min. die Strecke auf der Karte oder in der Fahr-Akademie ansehen.', 'Pro Themenblock eine Skizze auf einer Karteikarte, Vorfahrt in Grün, Warten in Rot.', 'Handy-Sperrbildschirm: jede Woche ein neues Verkehrszeichen.'],
  hoeren: ['Nach jeder Fahrstunde 2 Min. als Sprachnachricht erzählen: Was lief gut, was nicht?', 'Einmal pro Woche mit einem Freund 10 Theoriefragen abfragen, laut und mit Begründung.', 'Beim Mitfahren als Beifahrer laut kommentieren: Wer hat Vorfahrt? Warum?', 'Erklär-Videos nebenbei hören, z. B. auf dem Weg zur Schule.'],
  machen: ['Kreuzung auf Papier zeichnen und mit Münzen oder Spielzeugautos nachfahren.', 'Theoriefragen direkt vor der Fahrstunde lernen und dort bewusst anwenden.', 'Beim Spazierengehen an Kreuzungen stehen bleiben und die Vorfahrt ansagen.', 'Karteikarten-Duell: Wer zuerst richtig antwortet, bekommt die Karte.']
};

const css = `
@page { size: A4; margin: 14mm 14mm 14mm 14mm; }
* { box-sizing: border-box; }
body { font-family: Calibri, Carlito, Arial, sans-serif; color: #1D1F24; font-size: 10.5pt; line-height: 1.32; margin: 0; }
h1, h2, h3 { font-family: Cambria, Caladea, Georgia, serif; margin: 0; }
.page { page-break-after: always; position: relative; height: 268mm; overflow: hidden; }
.page:last-child { page-break-after: auto; }
.head { display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #1D1F24; padding-bottom: 6px; margin-bottom: 12px; }
.head .l { font-size: 9pt; letter-spacing: 2px; text-transform: uppercase; color: #6B6F78; font-weight: 700; }
.head .r { font-size: 9pt; color: #6B6F78; }
.title { display: flex; align-items: center; gap: 14px; margin-bottom: 10px; }
.badge { width: 58px; height: 58px; border-radius: 50%; border: 3px solid #E8650F; display: flex; align-items: center; justify-content: center; flex: none; }
.title h1 { font-size: 24pt; line-height: 1.05; }
.title .sub { font-size: 12pt; color: #E8650F; font-weight: 700; margin-top: 2px; }
.box { border: 1.5px solid #C9CCD2; border-radius: 10px; padding: 8px 11px; margin-bottom: 8px; }
.box.mission { border: 2.5px solid #E8650F; background: #FFF6EF; }
.box h3 { font-size: 13pt; margin-bottom: 4px; }
.kick { font-size: 8.5pt; letter-spacing: 2px; text-transform: uppercase; font-weight: 700; color: #E8650F; margin-bottom: 2px; }
.row { display: flex; gap: 10px; }
.row > .box { flex: 1; }
ul { margin: 4px 0 0 0; padding-left: 18px; } li { margin-bottom: 3px; }
.big { font-size: 15pt; font-weight: 700; }
.q4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-top: 6px; }
.q4 div { border: 1.5px solid #E8650F; border-radius: 8px; padding: 5px 6px; text-align: center; font-weight: 700; font-size: 10.5pt; }
.q4 small { display: block; font-weight: 400; color: #555; font-size: 8.5pt; }
.bad { color: #B3261E; } .good { color: #1E7A43; }
.roles { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-top: 4px; }
.roles div { border: 1px dashed #9AA0AA; border-radius: 8px; padding: 5px 7px; font-size: 9.5pt; min-height: 44px; }
.roles b { display: block; font-size: 10pt; }
.time { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0; margin-top: 4px; border: 1.5px solid #1D1F24; border-radius: 8px; overflow: hidden; }
.time div { padding: 5px 7px; font-size: 9.5pt; border-right: 1px solid #C9CCD2; } .time div:last-child { border-right: none; }
.time b { display: block; font-size: 10pt; color: #E8650F; }
.lines div { border-bottom: 1px solid #C9CCD2; height: 22px; }
.foot { position: absolute; bottom: 0; left: 0; right: 0; font-size: 8pt; color: #9AA0AA; display: flex; justify-content: space-between; }
/* Plakat-Vorlage */
.poster { border: 2.5px solid #1D1F24; border-radius: 12px; padding: 10px; height: 150mm; display: grid; grid-template-rows: 22mm 1fr 30mm; gap: 8px; }
.p-top { border: 1.5px dashed #9AA0AA; border-radius: 8px; display: flex; align-items: center; gap: 12px; padding: 0 12px; }
.p-top .t { font-family: Cambria, Caladea, serif; font-size: 17pt; font-weight: 700; }
.p-mid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
.tip { border: 2px solid #1D1F24; border-radius: 10px; padding: 8px; display: flex; flex-direction: column; }
.tip .n { font-family: Cambria, Caladea, serif; font-size: 24pt; font-weight: 700; color: #1F3A68; line-height: 1; }
.tip .f { border-bottom: 1px solid #E3D5CB; padding: 5px 0; font-size: 9pt; color: #6B6F78; flex: 1; }
.tip .f b { color: #1D1F24; }
.p-bot { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.p-bot div { border: 1.5px dashed #9AA0AA; border-radius: 8px; padding: 6px 10px; font-size: 9.5pt; color: #6B6F78; }
.p-bot b { color: #1D1F24; display: block; font-size: 10.5pt; }
.rules { display: grid; grid-template-columns: repeat(2, 1fr); gap: 4px 16px; font-size: 10pt; margin-top: 8px; }
.rules div::before { content: '✓ '; color: #1E7A43; font-weight: 700; }
.step { display: flex; gap: 10px; border: 1.5px solid #C9CCD2; border-radius: 10px; padding: 6px 10px; margin-bottom: 6px; }
.sn { flex: none; width: 30px; height: 30px; border-radius: 50%; background: #1D1F24; color: #fff; font-weight: 700; font-size: 14pt; display: flex; align-items: center; justify-content: center; margin-top: 2px; }
.sb { flex: 1; font-size: 10pt; }
.st { font-weight: 700; font-size: 11.5pt; margin-bottom: 2px; display: flex; justify-content: space-between; }
.st span { color: #E8650F; font-size: 10pt; }
ul.small li { margin-bottom: 0; font-size: 9.5pt; }
.note { font-size: 9.5pt; color: #444; margin-top: 5px; }
.checks { display: grid; grid-template-columns: 1fr 1fr; gap: 3px 16px; font-size: 10pt; }
.poster.sample { height: 150mm; grid-template-rows: 20mm 1fr 24mm; border-color: #1F3A68; }
.tip.s { border-color: #1F3A68; align-items: center; text-align: center; justify-content: space-between; }
.tip.s .n { color: #1F3A68; }
.tip.s .w { font-weight: 700; font-size: 14pt; line-height: 1.2; }
.tip.s .d { font-size: 8.5pt; color: #444; }
.w2 { display: block; font-weight: 700; font-size: 11.5pt; color: #1D1F24; }
.speech { background: #F6F7F9; border-radius: 8px; padding: 6px 10px; font-size: 10pt; }
.one .title h1 { font-size: 30pt; }
.one .big { font-size: 16pt; line-height: 1.25; }
.one .box.mission { padding: 12px 14px; margin-bottom: 12px; }
.tt { border: 1.5px solid #C9CCD2; border-radius: 10px; padding: 10px 12px; }
.ttg { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 16px; margin-top: 4px; font-size: 11pt; }
.ttg b { display: block; font-size: 12pt; margin-bottom: 1px; }
.sketch { border: 2.5px solid #1D1F24; border-radius: 12px; padding: 10px; height: 112mm; display: grid; grid-template-rows: 15mm 1fr 12mm; gap: 7px; }
.sk-top { display: flex; align-items: center; justify-content: center; gap: 10px; border-bottom: 2px solid #1F3A68; font-family: Cambria, Caladea, serif; font-size: 17pt; font-weight: 700; color: #1F3A68; }
.sk-mid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 9px; }
.sk-tip { border: 2px solid #1D1F24; border-radius: 9px; padding: 8px; display: flex; flex-direction: column; align-items: center; gap: 7px; }
.sk-n { font-family: Cambria, Caladea, serif; font-size: 26pt; font-weight: 700; color: #1F3A68; line-height: 1; }
.sk-l { height: 7px; background: #1D1F24; border-radius: 4px; } .w80 { width: 80%; } .w60 { width: 60%; }
.sk-small { font-size: 8.5pt; color: #6B6F78; text-align: center; }
.sk-ic { margin-top: auto; font-size: 9pt; color: #6B6F78; }
.sk-bot { border: 1.5px dashed #9AA0AA; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #1D1F24; font-size: 11pt; }
.sk-notes { display: flex; justify-content: space-between; font-size: 9.5pt; color: #444; margin-top: 5px; }
table { width: 100%; border-collapse: collapse; font-size: 10pt; }
td, th { border: 1px solid #C9CCD2; padding: 5px 7px; vertical-align: top; text-align: left; }
th { background: #F2F3F5; }
`;

const foot = (n) => `<div class="foot"><span>Fahrschule Boost · Fahrlehrer Serband · Lektion 12 „Lebenslanges Lernen“</span><span>${n}</span></div>`;

function sheet(g) {
  const sym = g.kanal === 'Sehen' ? 'Auge' : g.kanal === 'Hören' ? 'Ohr' : 'Hand';
  return `
<section class="page one">
  <div class="head"><span class="l">Gruppenarbeit · Lektion 12</span><span class="r">Namen: ______________________________</span></div>
  <div class="title"><div class="badge">${ic(g.icon, '#E8650F', 34)}</div>
    <div><div class="kick">Lernkanal ${g.kanal}</div><h1>Gruppe ${g.kanal.toUpperCase()}</h1><div class="sub">${g.typ}: ${g.sub}</div></div></div>

  <div class="box mission">
    <div class="kick">Eure Aufgabe · 15 Minuten</div>
    <div class="big">Findet 3 konkrete Lerntipps für „${g.typ}“. Macht daraus ein Plakat und stellt es in 1 Minute vor.</div>
    <div style="margin-top:3px">Recherchieren ist erlaubt: Handy, Internet, eigene Erfahrung.</div>
  </div>

  <div class="tt">
    <div class="kick">Tipps &amp; Tricks</div>
    <div class="ttg">
      <div><b>Konkret sein</b>Jeder Tipp sagt: Was? Wann? Womit? Wie lange?</div>
      <div><b>Beispiel</b><span class="bad">✗ „Videos gucken“</span><br><span class="good">✓ „Abends 20 Min. Lernvideos, danach 5 Testfragen“</span></div>
      <div><b>Ideen-Starter</b>${g.denk[0]}</div>
      <div><b>Groß schreiben</b>Druckbuchstaben, Überschrift ca. 5 cm, Tipps ca. 3 cm</div>
      <div><b>Farben</b>Nur Schwarz + eine dunkle Farbe. Kein Gelb, Rosa oder Neon.</div>
      <div><b>Vortrag</b>Nur 2 nach vorne: eine Person hält und zeigt, eine spricht.</div>
    </div>
  </div>

  <div class="kick" style="margin:10px 0 4px">So kann euer Plakat aussehen</div>
  <div class="sketch">
    <div class="sk-top">${ic(g.icon, '#1F3A68', 26)}<span>SO LERNT ${g.typ.toUpperCase()}</span></div>
    <div class="sk-mid">
      ${[1, 2, 3].map(n => `<div class="sk-tip"><div class="sk-n">${n}</div><div class="sk-l w80"></div><div class="sk-l w60"></div><div class="sk-small">Was · Wann · Womit · Wie lange</div><div class="sk-ic">◯ Symbol</div></div>`).join('')}
    </div>
    <div class="sk-bot">UNSER SATZ FÜR EUCH: ____________________</div>
  </div>
  <div class="sk-notes"><span>① Überschrift + Symbol (${sym})</span><span>② drei Tipps, groß nummeriert</span><span>③ ein Satz zum Merken</span></div>
  ${foot('Gruppe ' + g.kanal)}
</section>`;
}

function teacher() {
  return `
<section class="page">
  <div class="head"><span class="l">Nur für den Fahrlehrer</span><span class="r">Lektion 12 · Gruppenarbeit</span></div>
  <h1 style="font-size:24pt;margin-bottom:8px">Ablauf und Lösungsideen</h1>
  <div class="row">
    <div class="box"><div class="kick">Vorbereitung</div><ul>
      <li>Je Gruppe ihr Blatt drucken (1 Seite)</li>
      <li>Pro Gruppe 1 Plakat (Flipchart/A2), 1 Bleistift, 2 dicke schwarze Stifte und 1 dunkelblauer oder dunkelgrüner Stift</li>
      <li>Timer auf 15 Minuten (Folie „Eure Mission“ zeigt 15 MIN)</li>
      <li>Klebeband oder Magnete zum Aufhängen</li></ul></div>
    <div class="box"><div class="kick">Gruppen bilden</div><ul>
      <li>Nach dem QR-Test: Seher, Denker, Macher bilden je eine Gruppe</li>
      <li>Große Klasse: je Lerntyp 2 Gruppen (Blätter doppelt drucken)</li>
      <li>Eine Gruppe zu klein? Die „Mischtypen“ dorthin schicken</li>
      <li>Ideal: 3–5 Personen pro Gruppe</li></ul></div>
  </div>
  <div class="box"><div class="kick">Deine Rolle während der 15 Minuten</div>
    Herumgehen, zuhören, <b>keine Lösungen geben</b>. Hängt eine Gruppe, stell eine Frage aus den Denkanstößen auf ihrem Blatt. Achte darauf, dass die Tipps <b>konkret</b> sind (Was? Wann? Womit? Wie lange?). Zu allgemeine Tipps zurückgeben: „Was genau macht ihr da, und wann?“</div>
  <div class="box"><div class="kick">Auswertung (ca. 5 Minuten)</div>
    Pro Gruppe kommen <b>nur 2 Personen</b> nach vorne: eine hält und zeigt, eine spricht. 1 Minute pro Gruppe. Danach die Folie „Der Lern-Werkzeugkasten“ zeigen und ergänzen, was fehlt. Kernbotschaft: <b>Am stärksten ist, mehrere Kanäle zu kombinieren.</b></div>
  <div class="kick" style="margin:6px 0 4px">Lösungsideen (Erwartungshorizont)</div>
  <table><tr><th style="width:18%">Gruppe</th><th>Beispiele für gute, konkrete Tipps</th></tr>
    ${GROUPS.map(g => `<tr><td><b>${g.kanal}</b><br>${g.typ}</td><td><ul style="margin:0">${IDEEN[g.key].map(t => `<li>${t}</li>`).join('')}</ul></td></tr>`).join('')}
  </table>
  <div class="box" style="margin-top:8px"><div class="kick">Überleitung danach</div>„Ihr wisst jetzt, wie ihr lernt. Damit ihr das nicht allein durchziehen müsst, habe ich etwas gebaut …“ → weiter mit den Apps.</div>
  ${foot('Lehrerblatt')}
</section>`;
}

const html = `<!doctype html><html lang="de"><head><meta charset="utf-8"><title>Lektion 12 · Gruppenarbeit</title><style>${css}</style></head><body>
${teacher()}
${GROUPS.map(sheet).join('\n')}
</body></html>`;
const OUT = path.join(__dirname, 'worksheets');
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'arbeitsblaetter.html'), html);

(async () => {
  const { chromium } = require(require('child_process').execSync('npm root -g').toString().trim() + '/playwright');
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage();
  await p.goto('file://' + path.join(OUT, 'arbeitsblaetter.html'));
  await p.pdf({ path: path.join(OUT, 'Lektion12_Gruppenarbeit_Arbeitsblaetter.pdf'), format: 'A4', printBackground: true, preferCSSPageSize: true });
  await b.close();
  console.log('PDF fertig');
})();
