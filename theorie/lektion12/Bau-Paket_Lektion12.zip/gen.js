// Erzeugt Hintergründe, Foto-Grading, QR-Code und App-Assets für Lektion 12
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const QR = require('qrcode');
const OUT = path.join(__dirname, 'art');
const OLD = '/tmp/claude-0/-home-user-Fahrlehrer-Kompass-/2696f9dd-f251-5ae8-89e9-9ea308e4db74/scratchpad/l12/x/ppt/media';
const SHOTS = '/tmp/claude-0/-home-user-Fahrlehrer-Kompass-/2696f9dd-f251-5ae8-89e9-9ea308e4db74/scratchpad/apps/shots';
fs.mkdirSync(OUT, { recursive: true });

const W = 13.333, H = 7.5, PX = 1920;
const wrap = (body) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${PX}" height="${Math.round(PX * H / W)}">
<defs>
 <filter id="grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="7" numOctaves="2" seed="4"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 0.07"/></feComponentTransfer></filter>
 <radialGradient id="vig" cx="50%" cy="50%" r="75%"><stop offset="0.5" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.75"/></radialGradient>
 <filter id="soft"><feGaussianBlur stdDeviation="0.07"/></filter>
</defs>${body}<rect width="${W}" height="${H}" filter="url(#grain)"/><rect width="${W}" height="${H}" fill="url(#vig)"/></svg>`;
const glow = (id, col, cx, cy, r, op) => `<radialGradient id="${id}" cx="${cx}" cy="${cy}" r="${r}"><stop offset="0" stop-color="${col}" stop-opacity="${op}"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></radialGradient><rect width="${W}" height="${H}" fill="url(#${id})"/>`;
const jpg = (name, svg, q = 82) => sharp(Buffer.from(svg)).flatten({ background: '#07080B' }).jpeg({ quality: q, mozjpeg: true }).toFile(path.join(OUT, name + '.jpg'));

async function main() {
  const base = `<rect width="${W}" height="${H}" fill="#07080B"/>`;
  // Hintergründe: je Akt ein Lichtakzent
  await jpg('bg_orange', wrap(base + glow('a', '#FF6A13', 0.92, 0.05, 0.8, 0.30) + glow('b', '#2A3B55', 0.05, 1.0, 0.7, 0.45)));
  await jpg('bg_center', wrap(base + glow('a', '#FF7A1A', 0.5, 0.55, 0.55, 0.22) + glow('b', '#1B2538', 0.5, 1.1, 0.8, 0.5)));
  await jpg('bg_red', wrap(base + glow('a', '#FF3B3B', 0.9, 0.0, 0.75, 0.22) + glow('b', '#1A1F2B', 0.1, 1.0, 0.7, 0.4)));
  await jpg('bg_blue', wrap(base + glow('a', '#5B8CFF', 0.9, 0.0, 0.8, 0.20) + glow('b', '#FF7A1A', 0.0, 1.05, 0.6, 0.12)));
  await jpg('bg_green', wrap(`<rect width="${W}" height="${H}" fill="#060C0A"/>` + glow('a', '#3A7350', 0.85, 0.05, 0.85, 0.40) + glow('b', '#C9A227', 0.05, 1.0, 0.6, 0.14)));
  await jpg('bg_gold', wrap(`<rect width="${W}" height="${H}" fill="#0B0C0A"/>` + glow('a', '#D9954C', 0.88, 0.05, 0.85, 0.30) + glow('b', '#4B7A56', 0.05, 1.0, 0.7, 0.22)));
  await jpg('bg_black', wrap(`<rect width="${W}" height="${H}" fill="#030304"/>` + glow('a', '#FFFFFF', 0.5, 0.45, 0.6, 0.035)));
  // Bokeh für Titel und Abschluss
  let bk = base, rr = 7; const rnd = () => { rr = (rr * 9301 + 49297) % 233280; return rr / 233280; };
  const cols = ['#FF7A1A', '#FFB547', '#FF5C5C', '#FFE3B0', '#FF9A3C'];
  for (let i = 0; i < 55; i++) { const x = rnd() * W, y = 2.2 + rnd() * 5.3, r = 0.12 + rnd() * 0.6; bk += `<circle cx="${x}" cy="${y}" r="${r}" fill="${cols[Math.floor(rnd() * cols.length)]}" opacity="${0.06 + rnd() * 0.22}" filter="url(#soft)"/>`; }
  await jpg('bg_bokeh', wrap(bk + `<rect width="${W}" height="${H}" fill="#07080B" opacity="0.35"/>` + glow('a', '#FF6A13', 0.5, 1.1, 0.7, 0.25)));
  // Straße bei Nacht (Zeitstrahl): Asphalt-Band mit Mittellinie, perspektivisch
  await jpg('bg_road', wrap(base + glow('a', '#FF7A1A', 0.5, 0.62, 0.6, 0.16) + glow('b', '#22314A', 0.5, 0.0, 0.8, 0.35)));

  // Fotos: dunkel gegradet, leicht entsättigt, Kino-Look
  const grade = (src, name, w = 1400, h) => sharp(path.join(OLD, src)).resize(w, h || null, { fit: 'cover' })
    .modulate({ brightness: 0.78, saturation: 0.82 }).linear(1.08, -8).jpeg({ quality: 80, mozjpeg: true }).toFile(path.join(OUT, name + '.jpg'));
  await grade('image8.jpeg', 'p_handy', 1100, 760);
  await grade('image10.jpeg', 'p_telefon', 1100, 760);
  await grade('image9.jpeg', 'p_muede', 1100, 760);
  await grade('image11.jpeg', 'p_angeben', 1100, 760);
  await grade('image12.jpeg', 'p_niesen', 1100, 760);

  // Transparente Requisiten aus der alten Präsentation (verkleinert)
  const png = (src, name, w) => sharp(path.join(OLD, src)).resize(w).png({ compressionLevel: 9, palette: true, quality: 90 }).toFile(path.join(OUT, name + '.png'));
  await png('image41.png', 'mission', 700);
  await png('image39.png', 'phone_lerntest', 640);
  await png('image56.png', 'phone_kompass', 640);
  await png('image58.png', 'tablet_akademie', 760);
  // Echte App-Screenshots (Kompass) aus der alten Präsentation
  const shot = (src, name, w = 520) => sharp(path.join(OLD, src)).resize(w).jpeg({ quality: 84, mozjpeg: true }).toFile(path.join(OUT, name + '.jpg'));
  await shot('image49.jpeg', 'k_farbprofil');
  await shot('image50.jpeg', 'k_farbtext');
  await shot('image51.jpeg', 'k_plan');
  await shot('image52.jpeg', 'k_stufen');
  await shot('image53.jpeg', 'k_grundstufe');
  await shot('image54.jpeg', 'k_aufbaustufe');
  await shot('image59.jpeg', 'a_screens', 1400);
  await shot('image60.jpeg', 'a_videos', 1400);

  // Lerntyp-Check (eigene Aufnahme, Demo, nichts gespeichert)
  if (fs.existsSync(path.join(SHOTS, 'lt_start.png'))) await sharp(path.join(SHOTS, 'lt_start.png')).resize(600).jpeg({ quality: 86, mozjpeg: true }).toFile(path.join(OUT, 'lt_start.jpg'));
  for (const f of ['lt_ergebnis', 'mitdenken_frage', 'mitdenken_aufl', 'tr_player']) {
    const p = path.join(SHOTS, f + '.png');
    if (fs.existsSync(p)) await sharp(p).extract({ left: 0, top: 0, width: 1510, height: 1573 }).resize(1100).jpeg({ quality: 84, mozjpeg: true }).toFile(path.join(OUT, f + '.jpg'));
  }

  // QR-Code zum Lerntyp-Check, scharf, weiß auf transparent -> dunkel auf weiß (besser scannbar)
  await QR.toFile(path.join(OUT, 'qr_check.png'), 'https://serband1995-hue.github.io/Fahrlehrer-Kompass-/check.html',
    { width: 900, margin: 2, errorCorrectionLevel: 'M', color: { dark: '#0A0C10', light: '#FFFFFF' } });
  console.log('Grafiken fertig:', fs.readdirSync(OUT).length);
}
main().catch(e => { console.error(e); process.exit(1); });
