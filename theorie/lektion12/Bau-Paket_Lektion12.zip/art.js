// Erzeugt alle Grafiken für das Deck (SVG -> PNG/JPEG via sharp)
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const OUT = path.join(__dirname, 'art');
fs.mkdirSync(OUT, { recursive: true });
const SRC = '/tmp/pptx_review/extracted/ppt/media';

const W = 13.333, H = 7.5;           // Folie in Zoll
const PX = 2000;                       // Szenenbreite in px
const K = 0.22;                        // Zoll pro Meter (Standard-Maßstab)

const C = {
  bg: '#070B12', asphalt: '#1A222D', asphalt2: '#161D27', mark: '#D9DEE5', walk: '#252E3B', walk2: '#2B3544',
  block: '#0C1119', curb: '#3A4658', radweg: '#6E2A2E', grass: '#0E1A14', amber: '#FFB547', red: '#FF5C5C',
  green: '#38D98A', cyan: '#4CC9F0', white: '#F3F5F8'
};

// ---------- Hilfen ----------
const defs = `
<defs>
  <filter id="grain" x="0" y="0" width="100%" height="100%">
    <feTurbulence type="fractalNoise" baseFrequency="9" numOctaves="2" seed="3" result="n"/>
    <feColorMatrix type="saturate" values="0"/>
    <feComponentTransfer><feFuncA type="table" tableValues="0 0.10"/></feComponentTransfer>
  </filter>
  <radialGradient id="lamp" cx="50%" cy="50%" r="50%">
    <stop offset="0" stop-color="#FFD9A0" stop-opacity="0.20"/>
    <stop offset="0.5" stop-color="#FFC878" stop-opacity="0.07"/>
    <stop offset="1" stop-color="#FFC878" stop-opacity="0"/>
  </radialGradient>
  <radialGradient id="vig" cx="50%" cy="50%" r="75%">
    <stop offset="0.55" stop-color="#000" stop-opacity="0"/>
    <stop offset="1" stop-color="#000" stop-opacity="0.65"/>
  </radialGradient>
  <linearGradient id="leftfade" x1="0" y1="0" x2="1" y2="0">
    <stop offset="0" stop-color="${C.bg}" stop-opacity="0.96"/>
    <stop offset="0.75" stop-color="${C.bg}" stop-opacity="0.80"/>
    <stop offset="1" stop-color="${C.bg}" stop-opacity="0"/>
  </linearGradient>
  <linearGradient id="topfade" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="${C.bg}" stop-opacity="0.96"/>
    <stop offset="0.8" stop-color="${C.bg}" stop-opacity="0.78"/>
    <stop offset="1" stop-color="${C.bg}" stop-opacity="0"/>
  </linearGradient>
  <linearGradient id="botfade" x1="0" y1="1" x2="0" y2="0">
    <stop offset="0" stop-color="${C.bg}" stop-opacity="0.96"/>
    <stop offset="0.8" stop-color="${C.bg}" stop-opacity="0.78"/>
    <stop offset="1" stop-color="${C.bg}" stop-opacity="0"/>
  </linearGradient>
  <marker id="ah" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse">
    <path d="M0,0 L10,5 L0,10 z" fill="context-stroke"/>
  </marker>
  <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
    <feGaussianBlur stdDeviation="0.04" result="b"/>
    <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
  <filter id="soft"><feGaussianBlur stdDeviation="0.06"/></filter>
</defs>`;

const svgWrap = (body, w = W, h = H) =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${Math.round(PX * w / W)}" height="${Math.round(PX * h / W)}">${defs}${body}</svg>`;

const rect = (x, y, w, h, fill, extra = '') => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" ${extra}/>`;
const line = (x1, y1, x2, y2, col, sw, extra = '') => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${col}" stroke-width="${sw}" ${extra}/>`;
const dash = (x1, y1, x2, y2, sw = 0.035, d = '0.66 0.66') => line(x1, y1, x2, y2, C.mark, sw, `stroke-dasharray="${d}" opacity="0.85"`);
const solid = (x1, y1, x2, y2, sw = 0.035) => line(x1, y1, x2, y2, C.mark, sw, 'opacity="0.85"');
const lamp = (x, y, r = 1.3) => `<circle cx="${x}" cy="${y}" r="${r}" fill="url(#lamp)"/>`;
const grainAll = () => `<rect x="0" y="0" width="${W}" height="${H}" filter="url(#grain)"/>`;
const vignette = () => `<rect x="0" y="0" width="${W}" height="${H}" fill="url(#vig)"/>`;

// Häuserblöcke (Dächer) mit leichten Kanten
function blocks(x, y, w, h, seed = 1) {
  let s = rect(x, y, w, h, C.block);
  let r = seed * 9301;
  const rnd = () => { r = (r * 9301 + 49297) % 233280; return r / 233280; };
  // zufällige Dachflächen
  for (let i = 0; i < Math.max(2, Math.round(w * h / 1.6)); i++) {
    const bw = 0.6 + rnd() * 1.4, bh = 0.5 + rnd() * 1.2;
    const bx = x + rnd() * Math.max(0.01, w - bw), by = y + rnd() * Math.max(0.01, h - bh);
    s += rect(bx, by, Math.min(bw, w), Math.min(bh, h), rnd() > 0.5 ? '#111822' : '#0F151E', `rx="0.04" stroke="#18212D" stroke-width="0.02"`);
  }
  return s;
}

async function png(name, svg) { await sharp(Buffer.from(svg)).png({ compressionLevel: 9 }).toFile(path.join(OUT, name + '.png')); }
async function jpg(name, svg, q = 84) { await sharp(Buffer.from(svg)).flatten({ background: C.bg }).jpeg({ quality: q, mozjpeg: true }).toFile(path.join(OUT, name + '.jpg')); }

// ---------- Fahrzeuge (Draufsicht, Front nach oben) ----------
// Maße in Metern; Zeichenfläche mit Rand m
const M = 70; // px pro Meter für Sprites
function spriteSvg(wm, hm, body) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${wm} ${hm}" width="${Math.round(wm * M)}" height="${Math.round(hm * M)}">
  <defs>
   <filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.12"/></filter>
   <radialGradient id="bl" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#FFE3A3" stop-opacity="1"/><stop offset="0.25" stop-color="#FFB547" stop-opacity="0.95"/><stop offset="1" stop-color="#FF9A1F" stop-opacity="0"/></radialGradient>
  </defs>${body}</svg>`;
}
const CAR = { w: 1.8, l: 4.5, pad: 0.45 };
function carBody(col, col2, { wheels = 0, label = '', show = false } = {}) {
  const p = CAR.pad, w = CAR.w, l = CAR.l;
  const x = p, y = p;
  const wh = (cx, cy, ang) => `<rect x="${cx - 0.13}" y="${cy - 0.34}" width="0.26" height="0.68" rx="0.08" fill="#05070A" transform="rotate(${ang} ${cx} ${cy})"/>`;
  return `
  <rect x="${x + 0.05}" y="${y + 0.12}" width="${w}" height="${l}" rx="0.5" fill="#000" opacity="0.55" filter="url(#sh)"/>
  ${wh(x + 0.02, y + 1.05, wheels)}${wh(x + w - 0.02, y + 1.05, wheels)}${wh(x + 0.02, y + l - 1.0, 0)}${wh(x + w - 0.02, y + l - 1.0, 0)}
  <rect x="${x}" y="${y}" width="${w}" height="${l}" rx="0.55" fill="${col}"/>
  <rect x="${x + 0.12}" y="${y + 0.1}" width="${w - 0.24}" height="${l - 0.2}" rx="0.45" fill="${col2}" opacity="0.35"/>
  <path d="M${x + 0.2} ${y + 1.55} Q${x + w / 2} ${y + 1.2} ${x + w - 0.2} ${y + 1.55} L${x + w - 0.3} ${y + 2.05} L${x + 0.3} ${y + 2.05} Z" fill="#0A1018" opacity="0.92"/>
  <rect x="${x + 0.3}" y="${y + 2.05}" width="${w - 0.6}" height="1.25" rx="0.12" fill="${col2}" opacity="0.55"/>
  <path d="M${x + 0.32} ${y + 3.3} L${x + w - 0.32} ${y + 3.3} L${x + w - 0.24} ${y + 3.75} Q${x + w / 2} ${y + 3.9} ${x + 0.24} ${y + 3.75} Z" fill="#0A1018" opacity="0.9"/>
  <rect x="${x - 0.12}" y="${y + 1.5}" width="0.16" height="0.22" rx="0.05" fill="${col}"/><rect x="${x + w - 0.04}" y="${y + 1.5}" width="0.16" height="0.22" rx="0.05" fill="${col}"/>
  <rect x="${x + 0.18}" y="${y + 0.05}" width="0.42" height="0.14" rx="0.06" fill="#FFFFFF"/><rect x="${x + w - 0.6}" y="${y + 0.05}" width="0.42" height="0.14" rx="0.06" fill="#FFFFFF"/>
  <rect x="${x + 0.18}" y="${y + l - 0.17}" width="0.44" height="0.12" rx="0.05" fill="#FF3B3B"/><rect x="${x + w - 0.62}" y="${y + l - 0.17}" width="0.44" height="0.12" rx="0.05" fill="#FF3B3B"/>
  ${show ? `<g stroke="#FFFFFF" stroke-width="0.07">${wh(x + 0.3, y + 1.05, wheels)}${wh(x + w - 0.3, y + 1.05, wheels)}</g><line x1="${x + 0.3}" y1="${y + 1.05}" x2="${x + w - 0.3}" y2="${y + 1.05}" stroke="#0A1018" stroke-width="0.08"/>` : ''}
  ${label ? `<text x="${x + w / 2}" y="${y + 2.95}" font-family="Carlito, Calibri, Arial" font-weight="700" font-size="0.62" text-anchor="middle" fill="#0A1018">${label}</text>` : ''}`;
}
function carSvg(col, col2, opt) { return spriteSvg(CAR.w + 2 * CAR.pad, CAR.l + 2 * CAR.pad, carBody(col, col2, opt)); }
// Blinker-Leuchten auf gleicher Zeichenfläche
function blinkSvg(side, dims = CAR) {
  const p = dims.pad, w = dims.w, l = dims.l;
  const pts = [];
  if (side === 'L' || side === 'B') pts.push([p + 0.12, p + 0.12], [p + 0.12, p + l - 0.12]);
  if (side === 'R' || side === 'B') pts.push([p + w - 0.12, p + 0.12], [p + w - 0.12, p + l - 0.12]);
  const g = pts.map(([cx, cy]) => `<circle cx="${cx}" cy="${cy}" r="0.42" fill="url(#bl)"/>`).join('');
  return spriteSvg(w + 2 * p, l + 2 * p, g);
}
const TRUCK = { w: 2.55, l: 12, pad: 0.5 };
function truckSvg() {
  const p = TRUCK.pad, w = TRUCK.w, l = TRUCK.l, x = p, y = p;
  return spriteSvg(w + 2 * p, l + 2 * p, `
   <rect x="${x + 0.08}" y="${y + 0.15}" width="${w}" height="${l}" rx="0.25" fill="#000" opacity="0.55" filter="url(#sh)"/>
   <rect x="${x}" y="${y}" width="${w}" height="2.3" rx="0.35" fill="#C9D1DC"/>
   <rect x="${x + 0.2}" y="${y + 0.15}" width="${w - 0.4}" height="0.55" rx="0.1" fill="#0A1018"/>
   <rect x="${x - 0.28}" y="${y + 0.55}" width="0.3" height="0.45" rx="0.06" fill="#9AA6B5"/><rect x="${x + w - 0.02}" y="${y + 0.55}" width="0.3" height="0.45" rx="0.06" fill="#9AA6B5"/>
   <rect x="${x}" y="${y + 2.45}" width="${w}" height="${l - 2.45}" rx="0.15" fill="#E6EAF0"/>
   <rect x="${x + 0.15}" y="${y + 2.6}" width="${w - 0.3}" height="${l - 2.75}" rx="0.1" fill="#D5DBE3"/>
   ${[0, 1, 2, 3, 4, 5, 6].map(i => `<line x1="${x + 0.15}" y1="${y + 3.6 + i * 1.2}" x2="${x + w - 0.15}" y2="${y + 3.6 + i * 1.2}" stroke="#C3CAD4" stroke-width="0.05"/>`).join('')}
   <rect x="${x + 0.15}" y="${y + 0.02}" width="0.45" height="0.12" rx="0.05" fill="#fff"/><rect x="${x + w - 0.6}" y="${y + 0.02}" width="0.45" height="0.12" rx="0.05" fill="#fff"/>
   <rect x="${x + 0.15}" y="${y + l - 0.14}" width="0.5" height="0.12" rx="0.04" fill="#FF3B3B"/><rect x="${x + w - 0.65}" y="${y + l - 0.14}" width="0.5" height="0.12" rx="0.04" fill="#FF3B3B"/>`);
}
const BUS = { w: 2.55, l: 12, pad: 0.5 };
function busSvg() {
  const p = BUS.pad, w = BUS.w, l = BUS.l, x = p, y = p;
  return spriteSvg(w + 2 * p, l + 2 * p, `
   <rect x="${x + 0.08}" y="${y + 0.15}" width="${w}" height="${l}" rx="0.4" fill="#000" opacity="0.55" filter="url(#sh)"/>
   <rect x="${x}" y="${y}" width="${w}" height="${l}" rx="0.45" fill="#E9D46A"/>
   <rect x="${x + 0.15}" y="${y + 0.12}" width="${w - 0.3}" height="0.7" rx="0.15" fill="#0A1018"/>
   <rect x="${x + 0.3}" y="${y + 1.3}" width="${w - 0.6}" height="${l - 2.2}" rx="0.2" fill="#D8C35A"/>
   ${[0, 1, 2].map(i => `<rect x="${x + 0.6}" y="${y + 2.2 + i * 3.2}" width="${w - 1.2}" height="0.9" rx="0.1" fill="#BFAE4C"/>`).join('')}
   <text x="${x + w / 2}" y="${y + 6.6}" font-family="Carlito, Calibri, Arial" font-weight="700" font-size="0.9" text-anchor="middle" fill="#3A3413" transform="rotate(-90 ${x + w / 2} ${y + 6.3})">BUS</text>
   <rect x="${x + 0.15}" y="${y + 0.02}" width="0.45" height="0.12" rx="0.05" fill="#fff"/><rect x="${x + w - 0.6}" y="${y + 0.02}" width="0.45" height="0.12" rx="0.05" fill="#fff"/>
   <rect x="${x + 0.15}" y="${y + l - 0.14}" width="0.5" height="0.12" rx="0.04" fill="#FF3B3B"/><rect x="${x + w - 0.65}" y="${y + l - 0.14}" width="0.5" height="0.12" rx="0.04" fill="#FF3B3B"/>`);
}
const BIKE = { w: 0.7, l: 1.9, pad: 0.3 };
function bikeSvg(col = '#2EC4B6') {
  const p = BIKE.pad, w = BIKE.w, l = BIKE.l, cx = p + w / 2, y = p;
  return spriteSvg(w + 2 * p, l + 2 * p, `
   <ellipse cx="${cx + 0.04}" cy="${y + l / 2 + 0.08}" rx="0.4" ry="0.95" fill="#000" opacity="0.5" filter="url(#sh)"/>
   <rect x="${cx - 0.05}" y="${y}" width="0.1" height="0.62" rx="0.05" fill="#0B0F14"/>
   <rect x="${cx - 0.05}" y="${y + l - 0.62}" width="0.1" height="0.62" rx="0.05" fill="#0B0F14"/>
   <rect x="${cx - 0.34}" y="${y + 0.42}" width="0.68" height="0.07" rx="0.03" fill="#6B7785"/>
   <ellipse cx="${cx}" cy="${y + 0.95}" rx="0.33" ry="0.2" fill="${col}"/>
   <ellipse cx="${cx}" cy="${y + 1.12}" rx="0.19" ry="0.3" fill="${col}" opacity="0.85"/>
   <circle cx="${cx}" cy="${y + 0.86}" r="0.15" fill="#F3F5F8"/>
   <rect x="${cx - 0.05}" y="${y - 0.02}" width="0.1" height="0.07" fill="#FFFFFF"/>
   <rect x="${cx - 0.05}" y="${y + l - 0.05}" width="0.1" height="0.06" fill="#FF3B3B"/>`);
}
const PED = { w: 0.6, l: 0.45, pad: 0.25 };
function pedSvg(col = '#FF7AA8') {
  const p = PED.pad, w = PED.w, l = PED.l, cx = p + w / 2, cy = p + l / 2;
  return spriteSvg(w + 2 * p, l + 2 * p, `
   <ellipse cx="${cx + 0.03}" cy="${cy + 0.05}" rx="0.36" ry="0.26" fill="#000" opacity="0.55" filter="url(#sh)"/>
   <ellipse cx="${cx}" cy="${cy}" rx="0.32" ry="0.18" fill="${col}" stroke="#FFFFFF" stroke-width="0.035"/>
   <circle cx="${cx}" cy="${cy}" r="0.13" fill="#F3E3D3" stroke="#3A2A20" stroke-width="0.02"/>`);
}
const TRAC = { w: 2.3, l: 4.2, pad: 0.4 };
function tractorSvg() {
  const p = TRAC.pad, w = TRAC.w, l = TRAC.l, x = p, y = p;
  return spriteSvg(w + 2 * p, l + 2 * p, `
   <rect x="${x + 0.05}" y="${y + 0.12}" width="${w}" height="${l}" rx="0.3" fill="#000" opacity="0.5" filter="url(#sh)"/>
   <rect x="${x + 0.25}" y="${y + 0.2}" width="0.3" height="0.9" rx="0.1" fill="#05070A"/><rect x="${x + w - 0.55}" y="${y + 0.2}" width="0.3" height="0.9" rx="0.1" fill="#05070A"/>
   <rect x="${x - 0.05}" y="${y + 2.3}" width="0.55" height="1.6" rx="0.15" fill="#05070A"/><rect x="${x + w - 0.5}" y="${y + 2.3}" width="0.55" height="1.6" rx="0.15" fill="#05070A"/>
   <rect x="${x + 0.6}" y="${y}" width="${w - 1.2}" height="2.4" rx="0.2" fill="#3FA34D"/>
   <rect x="${x + 0.45}" y="${y + 2.2}" width="${w - 0.9}" height="1.8" rx="0.2" fill="#358A41"/>
   <rect x="${x + 0.65}" y="${y + 2.45}" width="${w - 1.3}" height="1.3" rx="0.12" fill="#0A1018" opacity="0.85"/>`);
}
const MOTO = { w: 0.8, l: 2.2, pad: 0.3 };
function motoSvg() {
  const p = MOTO.pad, w = MOTO.w, l = MOTO.l, cx = p + w / 2, y = p;
  return spriteSvg(w + 2 * p, l + 2 * p, `
   <ellipse cx="${cx + 0.04}" cy="${y + l / 2 + 0.08}" rx="0.45" ry="1.1" fill="#000" opacity="0.5" filter="url(#sh)"/>
   <rect x="${cx - 0.09}" y="${y}" width="0.18" height="0.7" rx="0.08" fill="#0B0F14"/>
   <rect x="${cx - 0.1}" y="${y + l - 0.7}" width="0.2" height="0.7" rx="0.08" fill="#0B0F14"/>
   <rect x="${cx - 0.38}" y="${y + 0.55}" width="0.76" height="0.08" rx="0.04" fill="#6B7785"/>
   <rect x="${cx - 0.2}" y="${y + 0.5}" width="0.4" height="1.2" rx="0.18" fill="#C04A5A"/>
   <ellipse cx="${cx}" cy="${y + 1.05}" rx="0.34" ry="0.22" fill="#2A2F38"/>
   <circle cx="${cx}" cy="${y + 0.95}" r="0.16" fill="#E6EAF0"/>
   <rect x="${cx - 0.07}" y="${y - 0.02}" width="0.14" height="0.08" fill="#FFFFFF"/>`);
}
function barrierSvg() { // Absperrschranke 3 m breit
  const wm = 3.4, hm = 1.2;
  let s = `<rect x="0.25" y="0.35" width="2.9" height="0.5" rx="0.05" fill="#F3F5F8"/>`;
  for (let i = 0; i < 6; i++) s += `<rect x="${0.25 + i * 0.5}" y="0.35" width="0.25" height="0.5" fill="#E23D3D"/>`;
  s += `<circle cx="0.35" cy="0.3" r="0.14" fill="#FFB547"/><circle cx="3.05" cy="0.3" r="0.14" fill="#FFB547"/>`;
  return spriteSvg(wm, hm, s);
}

// ---------- Szenen ----------
// Rechtsabbiegen: Hauptstraße vertikal, Seitenstraße nach Osten
const RS = { x0: 6.0, lane: 3.25 * K, curb: 0.1, rad: 2 * K, walk: 0.65, sy0: 2.2 };
RS.cx = RS.x0 + RS.lane;                  // Mittellinie
RS.x1 = RS.x0 + 2 * RS.lane;              // rechter Fahrbahnrand
RS.rx0 = RS.x1 + RS.curb; RS.rx1 = RS.rx0 + RS.rad; RS.wx1 = RS.rx1 + RS.walk;
RS.sy1 = RS.sy0 + 2 * RS.lane; RS.smid = RS.sy0 + RS.lane;
function sceneRechts() {
  const r = RS;
  let s = rect(0, 0, W, H, C.bg);
  s += blocks(0, 0, r.x0 - 0.65, H, 2);
  s += rect(r.x0 - 0.65, 0, 0.65, H, C.walk);
  s += blocks(r.wx1, 0, W - r.wx1, r.sy0 - 0.65, 5);
  s += blocks(r.wx1, r.sy1 + 0.65, W - r.wx1, H - r.sy1 - 0.65, 7);
  // Gehwege Seitenstraße
  s += rect(r.x1, r.sy0 - 0.65, W - r.x1, 0.65, C.walk);
  s += rect(r.x1, r.sy1, W - r.x1, 0.65, C.walk);
  // Radweg + Gehweg Ostseite der Hauptstraße
  s += rect(r.x1, 0, r.curb, H, C.curb);
  s += rect(r.rx0, 0, r.rad, H, C.radweg);
  s += rect(r.rx1, 0, r.walk, H, C.walk2);
  // Fahrbahn Hauptstraße + Seitenstraße
  s += rect(r.x0, 0, 2 * r.lane, H, C.asphalt);
  s += rect(r.x1, r.sy0, W - r.x1, 2 * r.lane, C.asphalt);
  // Radfurt über Seitenstraße
  s += rect(r.rx0, r.sy0, r.rad, 2 * r.lane, C.radweg, 'opacity="0.85"');
  s += dash(r.rx0, r.sy0, r.rx0, r.sy1, 0.03, '0.12 0.12') + dash(r.rx1, r.sy0, r.rx1, r.sy1, 0.03, '0.12 0.12');
  // Fahrradpiktogramme
  const bikeIcon = (x, y) => `<g opacity="0.55" stroke="#E7B9B9" stroke-width="0.025" fill="none"><circle cx="${x - 0.09}" cy="${y}" r="0.07"/><circle cx="${x + 0.09}" cy="${y}" r="0.07"/><path d="M${x - 0.09} ${y} L${x - 0.02} ${y - 0.1} L${x + 0.09} ${y} M${x - 0.02} ${y - 0.1} L${x + 0.05} ${y - 0.1}"/></g>`;
  s += bikeIcon(r.rx0 + r.rad / 2, 5.6) + bikeIcon(r.rx0 + r.rad / 2, 1.0);
  // Markierungen
  s += dash(r.cx, 0, r.cx, r.sy0 - 0.2) + dash(r.cx, r.sy1 + 0.2, r.cx, H);
  s += solid(r.x0 + 0.05, 0, r.x0 + 0.05, H, 0.025);
  s += dash(r.x1 + 0.4, r.smid, W, r.smid);
  // Leitlinie Kreuzung (Abbiegebereich)
  s += dash(r.x1 - 0.02, r.sy0, r.x1 - 0.02, r.sy1, 0.025, '0.2 0.2');
  // Laternen
  s += lamp(5.5, 1.2) + lamp(5.5, 4.6) + lamp(8.9, 1.5) + lamp(8.9, 4.4) + lamp(8.2, 7.0);
  s += grainAll() + vignette();
  s += rect(0, 0, 5.7, H, 'url(#leftfade)');
  return s;
}

// Linksabbiegen: Hauptstraße horizontal, Seitenstraße nach Süden (Abbieger kommt von Osten)
const LS = { y0: 3.0, lane: 3.25 * K, sx0: 4.0 };
LS.cy = LS.y0 + LS.lane; LS.y1 = LS.y0 + 2 * LS.lane; LS.sx1 = LS.sx0 + 2 * LS.lane; LS.smid = LS.sx0 + LS.lane;
function sceneLinks() {
  const r = LS;
  let s = rect(0, 0, W, H, C.bg);
  s += blocks(0, 0, W, r.y0 - 0.65, 3);
  s += blocks(0, r.y1 + 0.65, r.sx0 - 0.65, H, 4);
  s += blocks(r.sx1 + 0.65, r.y1 + 0.65, W, H, 8);
  s += rect(0, r.y0 - 0.65, W, 0.65, C.walk);
  s += rect(0, r.y1, W, 0.65, C.walk);
  s += rect(r.sx0 - 0.65, r.y1, 0.65, H, C.walk);
  s += rect(r.sx1, r.y1, 0.65, H, C.walk);
  s += rect(0, r.y0, W, 2 * r.lane, C.asphalt);
  s += rect(r.sx0, r.y1 - 0.01, 2 * r.lane, H, C.asphalt);
  s += dash(0, r.cy, r.sx0 - 0.3, r.cy) + dash(r.sx1 + 0.3, r.cy, W, r.cy);
  s += dash(r.smid, r.y1 + 0.9, r.smid, H);
  s += solid(0, r.y0 + 0.05, W, r.y0 + 0.05, 0.025);
  s += dash(r.sx0, r.y1 - 0.02, r.sx1, r.y1 - 0.02, 0.025, '0.2 0.2');
  s += lamp(2.2, r.y1 + 0.4) + lamp(6.2, r.y1 + 0.4) + lamp(9.5, r.y0 - 0.4) + lamp(12.4, r.y1 + 0.4) + lamp(3.4, r.y0 - 0.4);
  s += grainAll() + vignette();
  s += rect(0, 0, W, 2.55, 'url(#topfade)');
  return s;
}

// Landstraße horizontal (Überholen)
const US = { y0: 3.55, lane: 3.25 * K };
US.cy = US.y0 + US.lane; US.y1 = US.y0 + 2 * US.lane;
function sceneLand() {
  const r = US;
  let s = rect(0, 0, W, H, '#081009');
  s += `<rect x="0" y="0" width="${W}" height="${H}" fill="${C.grass}"/>`;
  s += rect(0, r.y0 - 0.12, W, 2 * r.lane + 0.24, '#20262C');
  s += rect(0, r.y0, W, 2 * r.lane, C.asphalt);
  s += solid(0, r.y0 + 0.05, W, r.y0 + 0.05, 0.03) + solid(0, r.y1 - 0.05, W, r.y1 - 0.05, 0.03);
  s += dash(0, r.cy, W, r.cy, 0.035, '0.9 0.45');
  // Leitpfosten
  for (let x = 0.4; x < W; x += 1.1) {
    s += rect(x, r.y0 - 0.3, 0.05, 0.05, '#E8ECF1') + rect(x + 0.012, r.y0 - 0.29, 0.026, 0.02, C.amber);
    s += rect(x + 0.55, r.y1 + 0.25, 0.05, 0.05, '#E8ECF1') + rect(x + 0.562, r.y1 + 0.26, 0.026, 0.02, '#FF6B6B');
  }
  // Bäume als dunkle Kronen
  let rr = 17; const rnd = () => { rr = (rr * 9301 + 49297) % 233280; return rr / 233280; };
  for (let i = 0; i < 26; i++) {
    const x = rnd() * W, top = rnd() > 0.5, y = top ? r.y0 - 0.9 - rnd() * 2.2 : r.y1 + 0.9 + rnd() * 2.0, rad = 0.25 + rnd() * 0.35;
    s += `<circle cx="${x}" cy="${y}" r="${rad}" fill="#07100A" opacity="0.9"/><circle cx="${x - rad * 0.2}" cy="${y - rad * 0.2}" r="${rad * 0.6}" fill="#0B170F" opacity="0.8"/>`;
  }
  s += grainAll() + vignette();
  s += rect(0, 0, W, 3.0, 'url(#topfade)');
  s += rect(0, 5.4, W, 2.1, 'url(#botfade)');
  return s;
}

// Große Straße für Tote-Winkel-Grafik (0,5 Zoll/m)
function sceneTW() {
  const k = 0.5, lane = 3.25 * k, x0 = 6.6;
  let s = rect(0, 0, W, H, C.bg);
  s += rect(x0, 0, 3 * lane, H, C.asphalt);
  s += dash(x0 + lane, 0, x0 + lane, H, 0.05, '1.5 1.5') + dash(x0 + 2 * lane, 0, x0 + 2 * lane, H, 0.05, '1.5 1.5');
  s += solid(x0 + 0.06, 0, x0 + 0.06, H, 0.04) + solid(x0 + 3 * lane - 0.06, 0, x0 + 3 * lane - 0.06, H, 0.04);
  s += rect(x0 - 0.8, 0, 0.8, H, C.walk) + rect(x0 + 3 * lane, 0, 0.8, H, C.walk);
  s += blocks(x0 + 3 * lane + 0.8, 0, W, H, 9);
  s += lamp(x0 - 0.3, 2) + lamp(x0 + 3 * lane + 0.4, 5.5);
  s += grainAll() + vignette();
  s += rect(0, 0, 6.4, H, 'url(#leftfade)');
  return s;
}

// Kreuzung (Voreinander / Quiz)
const KS = { vx0: 7.6, hy0: 3.03, lane: 3.25 * K };
KS.vmid = KS.vx0 + KS.lane; KS.vx1 = KS.vx0 + 2 * KS.lane; KS.hmid = KS.hy0 + KS.lane; KS.hy1 = KS.hy0 + 2 * KS.lane;
function sceneKreuz({ fadeLeft = true } = {}) {
  const r = KS, wk = 0.6;
  let s = rect(0, 0, W, H, C.bg);
  s += blocks(0, 0, r.vx0 - wk, r.hy0 - wk, 11) + blocks(r.vx1 + wk, 0, W, r.hy0 - wk, 12);
  s += blocks(0, r.hy1 + wk, r.vx0 - wk, H, 13) + blocks(r.vx1 + wk, r.hy1 + wk, W, H, 14);
  s += rect(0, r.hy0 - wk, W, wk, C.walk) + rect(0, r.hy1, W, wk, C.walk);
  s += rect(r.vx0 - wk, 0, wk, H, C.walk) + rect(r.vx1, 0, wk, H, C.walk);
  s += rect(0, r.hy0, W, 2 * r.lane, C.asphalt) + rect(r.vx0, 0, 2 * r.lane, H, C.asphalt);
  s += dash(r.vmid, 0, r.vmid, r.hy0 - 0.3) + dash(r.vmid, r.hy1 + 0.3, r.vmid, H);
  s += dash(0, r.hmid, r.vx0 - 0.3, r.hmid) + dash(r.vx1 + 0.3, r.hmid, W, r.hmid);
  s += lamp(r.vx0 - 0.4, r.hy0 - 0.4) + lamp(r.vx1 + 0.4, r.hy1 + 0.4) + lamp(3.5, r.hy1 + 0.3) + lamp(11.5, r.hy0 - 0.3);
  s += grainAll() + vignette();
  if (fadeLeft) s += rect(0, 0, 6.2, H, 'url(#leftfade)');
  return s;
}

// Stadtstraße horizontal mit Parkstreifen (Parken, Hindernis, Bus, Anfahren)
const SS = { y0: 3.3, lane: 3.25 * K, park: 2.2 * K };
SS.cy = SS.y0 + SS.lane; SS.y1 = SS.y0 + 2 * SS.lane; SS.py1 = SS.y1 + SS.park;
function sceneStadt({ busbucht = false } = {}) {
  const r = SS;
  let s = rect(0, 0, W, H, C.bg);
  s += blocks(0, 0, W, r.y0 - 0.7, 21) + blocks(0, r.py1 + 0.7, W, H, 22);
  s += rect(0, r.y0 - 0.7, W, 0.7, C.walk) + rect(0, r.py1, W, 0.7, C.walk);
  s += rect(0, r.y0, W, 2 * r.lane + r.park, C.asphalt);
  s += rect(0, r.y1, W, r.park, C.asphalt2);
  s += dash(0, r.cy, W, r.cy);
  s += line(0, r.y1, W, r.y1, C.mark, 0.02, 'opacity="0.35"');
  if (busbucht) {
    s += `<rect x="8.3" y="${r.py1 + 0.02}" width="3.2" height="0.25" fill="#E9D46A" opacity="0.25"/>`;
  }
  s += lamp(2, r.y0 - 0.4) + lamp(6.5, r.py1 + 0.4) + lamp(10.5, r.y0 - 0.4) + lamp(12.5, r.py1 + 0.4);
  s += grainAll() + vignette();
  s += rect(0, 0, W, 2.9, 'url(#topfade)');
  return s;
}

// T-Einmündung für 5 m / 8 m (Maßstab 0,25 Zoll/m)
const PS = { k: 0.25, y0: 2.6 };
PS.lane = 3.25 * PS.k; PS.y1 = PS.y0 + 2 * PS.lane; PS.cy = PS.y0 + PS.lane;
PS.rad0 = PS.y1 + 0.08; PS.rad1 = PS.rad0 + 2 * PS.k; PS.walk1 = PS.rad1 + 0.55;
PS.sx0 = 6.4; PS.sx1 = PS.sx0 + 2 * PS.lane;
function sceneEinm() {
  const r = PS;
  let s = rect(0, 0, W, H, C.bg);
  s += blocks(0, 0, W, r.y0 - 0.6, 31);
  s += blocks(0, r.walk1, r.sx0 - 0.2, H, 32) + blocks(r.sx1 + 0.2, r.walk1, W, H, 33);
  s += rect(0, r.y0 - 0.6, W, 0.6, C.walk);
  s += rect(0, r.y1, W, 0.08, C.curb);
  s += rect(0, r.rad0, W, r.rad1 - r.rad0, C.radweg);
  s += rect(0, r.rad1, W, 0.55, C.walk2);
  s += rect(0, r.y0, W, 2 * r.lane, C.asphalt);
  s += rect(r.sx0, r.y1, r.sx1 - r.sx0, H, C.asphalt);
  s += rect(r.sx0 - 0.02, r.rad0, 0.02, r.walk1 - r.rad0, C.curb) + rect(r.sx1, r.rad0, 0.02, r.walk1 - r.rad0, C.curb);
  s += rect(r.sx0, r.rad0, r.sx1 - r.sx0, r.rad1 - r.rad0, C.radweg, 'opacity="0.85"');
  s += dash(r.sx0, r.rad0, r.sx1, r.rad0, 0.025, '0.12 0.12') + dash(r.sx0, r.rad1, r.sx1, r.rad1, 0.025, '0.12 0.12');
  s += dash(0, r.cy, W, r.cy, 0.035, '0.75 0.75');
  s += dash(r.sx0 + r.lane, r.walk1 + 0.3, r.sx0 + r.lane, H, 0.035, '0.75 0.75');
  // Schnittpunkte der Fahrbahnkanten (verlängert)
  s += line(r.sx0, r.y1, r.sx0, r.walk1, '#FFB547', 0.02, 'stroke-dasharray="0.06 0.06" opacity="0.8"');
  s += line(r.sx1, r.y1, r.sx1, r.walk1, '#FFB547', 0.02, 'stroke-dasharray="0.06 0.06" opacity="0.8"');
  s += lamp(3, r.y0 - 0.3) + lamp(10, r.y0 - 0.3) + lamp(r.sx0 - 0.4, 5.5);
  s += grainAll() + vignette();
  return s;
}

// ---------- Overlays (transparent, volle Folie) ----------
const arrowPath = (d, col, sw = 0.06, dashA = '') =>
  `<path d="${d}" stroke="${col}" stroke-width="${sw}" fill="none" stroke-linecap="round" ${dashA ? `stroke-dasharray="${dashA}"` : ''} marker-end="url(#ah)" filter="url(#glow)"/>`;
const cone = (x, y, ang, spread, len, col, op = 0.28) => { // Blickkegel (Grad, 0 = nach oben)
  const a1 = (ang - spread / 2 - 90) * Math.PI / 180, a2 = (ang + spread / 2 - 90) * Math.PI / 180;
  const p1 = [x + len * Math.cos(a1), y + len * Math.sin(a1)], p2 = [x + len * Math.cos(a2), y + len * Math.sin(a2)];
  return `<path d="M${x} ${y} L${p1[0]} ${p1[1]} A${len} ${len} 0 0 1 ${p2[0]} ${p2[1]} Z" fill="${col}" opacity="${op}"/>`;
};

async function build() {
  // Fotos (Nutzer-Material) leicht gegradet
  const photos = { p_city: 'image.png', p_truck: 'image10.png', p_bike: 'image16.png', p_land: 'image17.png', p_mirror: 'image2.png', p_park: 'image22.png', p_door: 'image32.png' };
  for (const [k, f] of Object.entries(photos)) {
    await sharp(path.join(SRC, f)).resize(1672, 941).modulate({ brightness: 0.92, saturation: 0.95 }).jpeg({ quality: 82, mozjpeg: true }).toFile(path.join(OUT, k + '.jpg'));
  }
  // Hintergründe
  const bgV = (glowCol, gx, gy, op) => svgWrap(`${rect(0, 0, W, H, C.bg)}
    <radialGradient id="g1" cx="${gx}" cy="${gy}" r="0.75"><stop offset="0" stop-color="${glowCol}" stop-opacity="${op}"/><stop offset="1" stop-color="${glowCol}" stop-opacity="0"/></radialGradient>
    <radialGradient id="g2" cx="0.1" cy="1.0" r="0.7"><stop offset="0" stop-color="#1B3350" stop-opacity="0.55"/><stop offset="1" stop-color="#1B3350" stop-opacity="0"/></radialGradient>
    ${rect(0, 0, W, H, 'url(#g2)')}${rect(0, 0, W, H, 'url(#g1)')}${grainAll()}${vignette()}`);
  await jpg('bg_amber', bgV('#FFB547', 0.92, 0.0, 0.22));
  await jpg('bg_cyan', bgV('#4CC9F0', 0.92, 0.0, 0.16));
  await jpg('bg_red', bgV('#FF5C5C', 0.92, 0.0, 0.18));
  await jpg('bg_green', bgV('#38D98A', 0.92, 0.0, 0.14));
  await jpg('bg_blue', bgV('#7AA2FF', 0.92, 0.0, 0.18));
  // Bokeh (Nacht-Lichter, unscharf)
  let bk = rect(0, 0, W, H, '#05080D'); let rr = 5; const rnd = () => { rr = (rr * 9301 + 49297) % 233280; return rr / 233280; };
  const cols = ['#FFB547', '#FFD9A0', '#FF5C5C', '#F3F5F8', '#4CC9F0'];
  for (let i = 0; i < 46; i++) { const x = rnd() * W, y = 1.5 + rnd() * 5.5, rad = 0.15 + rnd() * 0.65; bk += `<circle cx="${x}" cy="${y}" r="${rad}" fill="${cols[Math.floor(rnd() * cols.length)]}" opacity="${0.08 + rnd() * 0.22}" filter="url(#soft)"/>`; }
  await jpg('bg_bokeh', svgWrap(`${bk}<rect width="${W}" height="${H}" fill="#05080D" opacity="0.35"/>${grainAll()}${vignette()}`));

  // Szenen
  await jpg('sc_rechts', svgWrap(sceneRechts()));
  await jpg('sc_links', svgWrap(sceneLinks()));
  await jpg('sc_land', svgWrap(sceneLand()));
  await jpg('sc_tw', svgWrap(sceneTW()));
  await jpg('sc_kreuz', svgWrap(sceneKreuz()));
  await jpg('sc_stadt', svgWrap(sceneStadt()));
  await jpg('sc_stadtbus', svgWrap(sceneStadt({ busbucht: true })));
  await jpg('sc_einm', svgWrap(sceneEinm()));

  // Sprites
  await png('car_du', carSvg('#FFB547', '#FFE2B0', { label: '' }));
  await png('car_du_wl', carSvg('#FFB547', '#FFE2B0', { wheels: -26, show: true }));
  await png('car_du_w0', carSvg('#FFB547', '#FFE2B0', { wheels: 0, show: true }));
  await png('car_grau', carSvg('#8A9BB0', '#C9D3DF'));
  await png('car_blau', carSvg('#4F78A8', '#9DB8D8'));
  await png('car_rot', carSvg('#B84A55', '#E09AA2'));
  await png('car_weiss', carSvg('#D9DFE7', '#FFFFFF'));
  await png('blink_L', blinkSvg('L')); await png('blink_R', blinkSvg('R')); await png('blink_B', blinkSvg('B'));
  await png('bus_blink', blinkSvg('B', BUS)); await png('truck_blink_R', blinkSvg('R', TRUCK));
  await png('truck', truckSvg()); await png('bus', busSvg());
  await png('bike', bikeSvg()); await png('moto', motoSvg()); await png('ped', pedSvg()); await png('ped_a', pedSvg('#B08CFF'));
  await png('tractor', tractorSvg()); await png('barrier', barrierSvg());

  // Overlays Rechtsabbiegen
  const cxR = RS.cx + RS.lane / 2;
  await png('ov_r_spiegel', svgWrap(cone(cxR, 5.95, 180, 26, 2.6, C.cyan, 0.22) + cone(cxR - 0.2, 5.55, 196, 20, 2.4, C.cyan, 0.16) + cone(cxR + 0.2, 5.55, 164, 20, 2.4, C.cyan, 0.16)));
  await png('ov_r_schulter1', svgWrap(cone(cxR + 0.1, 4.9, 130, 34, 1.9, C.amber, 0.30)));
  await png('ov_r_schulter2', svgWrap(cone(cxR + 0.14, 3.9, 130, 34, 1.9, C.amber, 0.30)));
  // Toter Winkel Pkw (Maßstab 0,5)
  {
    const k = 0.5, lane = 3.25 * k, x0 = 6.6, cx = x0 + 1.5 * lane, cy = 3.6;
    const mir = cone(cx, cy + 0.6, 180, 22, 4.4, C.cyan, 0.22) + cone(cx - 0.5, cy - 0.25, 200, 18, 4.2, C.cyan, 0.2) + cone(cx + 0.5, cy - 0.25, 160, 18, 4.2, C.cyan, 0.2);
    await png('ov_tw_spiegel', svgWrap(mir));
    const tw = `<path d="M${cx - 0.48} ${cy - 0.2} L${cx - 1.6} ${cy + 0.1} L${cx - 1.95} ${cy + 1.9} L${cx - 0.9} ${cy + 1.2} Z" fill="${C.red}" opacity="0.38"/>
                <path d="M${cx + 0.48} ${cy - 0.2} L${cx + 1.6} ${cy + 0.1} L${cx + 1.95} ${cy + 1.9} L${cx + 0.9} ${cy + 1.2} Z" fill="${C.red}" opacity="0.38"/>`;
    await png('ov_tw_rot', svgWrap(tw));
  }
  // Lkw toter Winkel (auf Szene Rechts)
  {
    const tx = RS.cx + RS.lane / 2, ty = 4.7, tl = 12 * K;
    const z = `<path d="M${tx + 0.3} ${ty - tl / 2 + 0.2} L${RS.wx1 + 0.6} ${ty - tl / 2 - 0.3} L${RS.wx1 + 0.6} ${ty + tl / 2 + 0.4} L${tx + 0.3} ${ty + tl / 2} Z" fill="${C.red}" opacity="0.36"/>
               <path d="M${tx - 0.3} ${ty - tl / 2 - 0.05} L${tx + 0.3} ${ty - tl / 2 - 0.05} L${tx + 0.55} ${ty - tl / 2 - 0.55} L${tx - 0.55} ${ty - tl / 2 - 0.55} Z" fill="${C.red}" opacity="0.30"/>`;
    await png('ov_lkw_rot', svgWrap(z));
  }
  // Voreinander / Hintereinander
  {
    const r = KS, aX = r.vmid + r.lane / 2, bX = r.vmid - r.lane / 2, wY = r.hmid - r.lane / 2, eY = r.hmid + r.lane / 2;
    const vorA = `M${aX} 5.2 C${aX} 4.3 ${aX - 0.4} ${r.hmid + 0.15} ${r.vx0 - 0.6} ${wY}`;
    const vorB = `M${bX} 1.8 C${bX} 2.75 ${bX + 0.4} ${r.hmid - 0.15} ${r.vx1 + 0.6} ${eY}`;
    await png('ov_vor', svgWrap(arrowPath(vorA, C.amber, 0.06) + arrowPath(vorB, '#B9C4D2', 0.06, '0.14 0.1')));
    const hinA = `M${aX} 5.2 C${aX} 3.2 ${aX - 0.1} ${r.hy0 - 0.1} ${r.vmid - 0.2} ${wY} S ${r.vx0 - 0.3} ${wY} ${r.vx0 - 0.9} ${wY}`;
    const hinB = `M${bX} 1.8 C${bX} 3.8 ${bX + 0.1} ${r.hy1 + 0.1} ${r.vmid + 0.2} ${eY} S ${r.vx1 + 0.3} ${eY} ${r.vx1 + 0.9} ${eY}`;
    await png('ov_hinter', svgWrap(arrowPath(hinA, C.amber, 0.06) + arrowPath(hinB, '#B9C4D2', 0.06, '0.14 0.1')));
  }
  // Räder gerade (Szene Links) – wartendes Auto fährt nach Westen
  {
    const y = LS.cy - 0.22, x = 5.05;
    await png('ov_raeder_schraeg', svgWrap(arrowPath(`M${x - 0.6} ${y} Q ${x - 1.2} ${y + 0.1} ${x - 1.7} ${LS.y1 - 0.25}`, C.red, 0.08)));
    await png('ov_raeder_gerade', svgWrap(arrowPath(`M${x - 0.6} ${y} L ${x - 1.9} ${y}`, C.green, 0.08)));
    await png('ov_stoss', svgWrap(`<g filter="url(#glow)" transform="translate(${x + 0.53 - 7.63 - 0.08} ${y - (LS.cy + 0.13)})"><path d="M7.63 ${LS.cy + 0.13 - 0.22} l0.08 0.14 l0.16 -0.06 l-0.05 0.15 l0.15 0.07 l-0.15 0.06 l0.04 0.16 l-0.15 -0.07 l-0.08 0.14 l-0.06 -0.15 l-0.16 0.05 l0.07 -0.15 l-0.14 -0.08 l0.16 -0.04 z" fill="${C.red}"/></g>`));
  }
  // Überholweg-Pfeil (Szene Land)
  await png('ov_ueberholweg', svgWrap(arrowPath(`M2.3 ${US.cy + US.lane / 2} C3.2 ${US.cy + US.lane / 2} 3.6 ${US.cy - US.lane / 2} 4.6 ${US.cy - US.lane / 2} L9.4 ${US.cy - US.lane / 2} C10.4 ${US.cy - US.lane / 2} 10.8 ${US.cy + US.lane / 2} 11.8 ${US.cy + US.lane / 2}`, C.amber, 0.05, '0.16 0.1')));
  // Parkverbotszonen Einmündung
  {
    const r = PS, k = r.k, py = r.y1 - 2.0 * k - 0.02, ph = 2.0 * k;
    await png('ov_zone8', svgWrap(`<rect x="${r.sx0 - 8 * k}" y="${py}" width="${8 * k}" height="${ph}" fill="${C.red}" opacity="0.38" rx="0.03"/>`));
    await png('ov_zone5', svgWrap(`<rect x="${r.sx1}" y="${py}" width="${5 * k}" height="${ph}" fill="${C.red}" opacity="0.38" rx="0.03"/>`));
    await png('ov_zone5b', svgWrap(`<rect x="${r.sx0 - 5 * k}" y="${py}" width="${5 * k}" height="${ph}" fill="${C.red}" opacity="0.38" rx="0.03"/>`));
  }
  // Anfahren: Schulterblick links hinten
  await png('ov_anfahren', svgWrap(cone(6.75, SS.y1 + 0.2, 283, 34, 2.9, C.amber, 0.3)));
  await png('car_du_wr', carSvg('#FFB547', '#FFE2B0', { wheels: 26, show: true }));
  await png('grad_left', svgWrap(`<linearGradient id="gl" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#05080D" stop-opacity="0.94"/><stop offset="0.45" stop-color="#05080D" stop-opacity="0.72"/><stop offset="0.8" stop-color="#05080D" stop-opacity="0.1"/><stop offset="1" stop-color="#05080D" stop-opacity="0"/></linearGradient><rect width="${W}" height="${H}" fill="url(#gl)"/>`));
  await png('grad_bottom', svgWrap(`<linearGradient id="gb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#05080D" stop-opacity="0.15"/><stop offset="0.45" stop-color="#05080D" stop-opacity="0.35"/><stop offset="1" stop-color="#05080D" stop-opacity="0.95"/></linearGradient><rect width="2.85" height="3.6" fill="url(#gb)"/>`, 2.85, 3.6));
  await sharp(path.join(SRC, 'image.png')).extract({ left: 560, top: 220, width: 1100, height: 619 }).resize(1672, 941).modulate({ brightness: 0.9 }).jpeg({ quality: 82, mozjpeg: true }).toFile(path.join(OUT, 'p_city_crop.jpg'));

  // Verkehrszeichen: amtliche Grafiken (Wikimedia Commons / OSM-Wiki, gemeinfrei als amtliche Werke), nicht selbst gezeichnet
  const dims = {};
  for (const f of fs.readdirSync('/tmp/ots/png')) {
    const id = f.replace(/^z/, '').replace(/\.png$/, '');
    if (!['276', '277', '277_1', '283', '286', '295', '224', '314', '315_50', '306', '205', '206', '201', '340', '350'].includes(id)) continue;
    const m = await sharp(path.join('/tmp/ots/png', f)).metadata();
    fs.copyFileSync(path.join('/tmp/ots/png', f), path.join(OUT, 'sign_' + id + '.png'));
    dims[id] = m.width / m.height;
  }
  fs.writeFileSync(path.join(OUT, 'signs.json'), JSON.stringify(dims));
  console.log('Grafiken fertig:', fs.readdirSync(OUT).length);
}
module.exports = { RS, LS, US, KS, SS, PS, K, CAR, TRUCK, BUS, BIKE, PED, TRAC, MOTO };
if (require.main === module) build().catch(e => { console.error(e); process.exit(1); });
