// Statistik-Sequenz: Wette → Rennen (10 Jahre, Männer gegen Frauen) → Alter → Pointe
// Daten: Statistisches Bundesamt, Verkehrstote je Jahr 2016–2025; Männeranteil rund 76 % (Destatis 2020: 75,9 %)
const YEARS = [[2016, 3206], [2017, 3180], [2018, 3275], [2019, 3046], [2020, 2719], [2021, 2562], [2022, 2788], [2023, 2839], [2024, 2770], [2025, 2832]];
const SHARE_M = 0.76;
const BLUE = '4A8BFF', PINK = 'FF6FB1';
const fmt = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const r100 = n => Math.round(n / 100) * 100;

// Geometrie Thermometer auf Folie B (Mitte) und C (klein, außen)
const TB = { top: 1.45, tubeH: 3.9, tubeW: 0.95, bulb: 1.45, max: 24000 };
function thermo(s, COL, x, col, prefix, geo, anim) {
  const { top, tubeH, tubeW, bulb } = geo;
  const cx = x + tubeW / 2;
  s.rrect(x, top, tubeW, tubeH, { fill: '11151C', line: '3A4252', lw: 2, rr: 0.5, name: `!!${prefix}tube` }, anim);
  s.oval(cx - bulb / 2, top + tubeH - bulb * 0.35, bulb, bulb, { fill: col, line: '3A4252', lw: 2, glow: 14, glowColor: col, glowOp: 0.45, name: `!!${prefix}bulb` }, anim);
  return { cx, innerTop: top + 0.12, innerBot: top + tubeH, innerW: tubeW - 0.36 };
}

async function statsSlides(deck, ctx) {
  const { COL, SERIF, W, footer, kicker, title, chip, run, I, pres, icon } = ctx;
  const gIcon = async (name, col) => { const React = require('react'), RDS = require('react-dom/server'), T = require('react-icons/tb');
    const svg = RDS.renderToStaticMarkup(React.createElement(T[name], { color: '#' + col, size: '256', strokeWidth: 1.8 }));
    return 'image/png;base64,' + (await require('sharp')(Buffer.from(svg)).png().toBuffer()).toString('base64'); };
  const MARS = await gIcon('TbGenderMale', BLUE), VENUS = await gIcon('TbGenderFemale', PINK);
  const TOTAL = YEARS.reduce((a, [, v]) => a + v, 0); // 29.217

  // ---------- A · DIE WETTE ----------
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'black', footer: false, notes: `
❓ Frage an die Klasse: Wer ist der bessere Autofahrer, Männer oder Frauen? Reinrufen lassen, abstimmen lassen, ruhig ein bisschen Stimmung machen. Nichts auflösen.
🖱 1 Klick: „Let's go“, wir schauen uns die Zahlen an.
➜ Weiterklicken: Das Rennen der letzten zehn Jahre startet.` });
    kicker(s, 'Eine Wette', 0.8, 1.0, { w: 11.7, align: 'center' });
    title(s, 'Wer ist der bessere Autofahrer?', 0.8, 1.4, 11.7, 1.1, { size: 54, align: 'center' }, { fx: 'fade', auto: true, dur: 1000 });
    const card = (x, col, sym, label, pre) => {
      s.rrect(x, 3.0, 3.6, 2.7, { fill: '10141B', line: col, lw: 2.5, rr: 0.14, glow: 16, glowColor: col, glowOp: 0.3, name: `!!${pre}card` }, { fx: 'rise', auto: true, a: true, dur: 700 });
      s.img(sym, { x: x + 1.2, y: 3.2, w: 1.2, h: 1.2, name: `!!${pre}sym` }, { fx: 'fade', auto: true, dur: 500 });
      s.text(label, { x, y: 4.55, w: 3.6, h: 0.8, font: SERIF, size: 38, bold: true, align: 'center', name: `!!${pre}lab` }, { fx: 'fade', auto: true, dur: 500 });
    };
    card(2.3, BLUE, MARS, 'Männer', 'm');
    s.text('oder', { x: 5.9, y: 3.9, w: 1.55, h: 0.8, font: SERIF, size: 30, italic: true, color: COL.muted, align: 'center' }, { fx: 'fade', auto: true, a: true });
    card(7.45, PINK, VENUS, 'Frauen', 'w');
    s.text("LET'S GO", { x: 4.9, y: 6.1, w: 3.55, h: 0.8, size: 30, bold: true, cs: 4, color: '1A0E05', fill: COL.orange, shape: pres.shapes.ROUNDED_RECTANGLE, rr: 0.25, align: 'center', valign: 'middle', rotate: -3, glow: 16, glowOp: 0.5 }, { fx: 'stamp', c: true, dur: 420 });
  }

  // ---------- B · DAS RENNEN ----------
  const xM = 3.9, xW = 8.45;
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'morph', dur: 1300, footer: false, notes: `
🖱 1 Klick: Das Rennen läuft von selbst, ein Jahr pro Sekunde, von 2016 bis 2025. Mitkommentieren: „2016 … 2017 … schaut euch Blau an …“
Am Ende stehen die Säulen: rund 22.000 Männer, rund 7.000 Frauen. Kurz wirken lassen, fragen: Wer lag richtig?
🖱 2. Klick: Stempel „3 von 4 Verkehrstoten sind Männer“.
🖱 3. Klick: Zusammen fast 30.000 Menschen in zehn Jahren (genau 29.217). So viele Einwohner hat eine Kleinstadt. Kurz wirken lassen.
Fair bleiben: Tote heißt nicht automatisch „schlechter fahren“. Männer fahren mehr Kilometer und öfter Motorrad. Sie verursachen aber auch häufiger schwere Unfälle (Destatis). Und sie überschätzen sich häufiger.
Quelle: Statistisches Bundesamt, Verkehrstote 2016–2025. Aufteilung nach Geschlecht gerundet (Männeranteil rund 76 %).` });
    kicker(s, '10 Jahre auf deutschen Straßen', 0.8, 0.35, { w: 11.7, align: 'center', name: '!!k' });
    // Skala
    const g = TB, sc = v => g.top + g.tubeH - 0.12 - (g.tubeH - 0.3) * v / g.max;
    for (const v of [0, 5000, 10000, 15000, 20000]) {
      s.text(fmt(v), { x: 0.3, y: sc(v) - 0.17, w: 1.1, h: 0.34, size: 14, color: COL.dim, align: 'right', name: `!!sc${v}` });
      s.lineS(1.55, sc(v), 11.8, sc(v), { color: '232A36', lw: 1, dash: 'dash', name: `!!gl${v}` });
    }
    const tm = thermo(s, COL, xM, BLUE, 'm', g);
    const tw = thermo(s, COL, xW, PINK, 'w', g);
    s.img(MARS, { x: xM - 0.55, y: 0.8, w: 0.42, h: 0.42, name: '!!msy' });
    s.text('Männer', { x: xM - 0.05, y: 0.78, w: 1.8, h: 0.48, size: 22, bold: true, color: BLUE, name: '!!mlab' });
    s.img(VENUS, { x: xW - 0.55, y: 0.8, w: 0.42, h: 0.42, name: '!!wsy' });
    s.text('Frauen', { x: xW - 0.05, y: 0.78, w: 1.8, h: 0.48, size: 22, bold: true, color: PINK, name: '!!wlab' });
    // Rennen: pro Jahr ein Segment je Säule + Zählerstand + Jahreszahl
    let cm = 0, cw = 0, prev = null;
    YEARS.forEach(([y, v], i) => {
      const m = v * SHARE_M, w = v - m;
      const segM = (g.tubeH - 0.3) * m / g.max, segW = (g.tubeH - 0.3) * w / g.max;
      const yM = sc(cm + m), yW = sc(cw + w);
      const first = i === 0 ? { c: true } : { a: true };
      const step = 850;
      // Jahreszahl
      const yr = s.text(String(y), { x: 5.55, y: 1.45, w: 2.3, h: 0.9, font: SERIF, size: 54, bold: true, color: COL.txt, align: 'center', valign: 'middle' }, { fx: 'fade', ...first, dur: 150 });
      if (prev) { s.reg(prev.yr, { fx: 'out', dur: 150 }, 'sp'); s.reg(prev.nm, { fx: 'out', dur: 150 }, 'sp'); s.reg(prev.nw, { fx: 'out', dur: 150 }, 'sp'); }
      s.rect(tm.cx - tm.innerW / 2, yM, tm.innerW, segM + 0.005, { fill: BLUE }, { fx: 'wipeU', dur: step });
      s.rect(tw.cx - tw.innerW / 2, yW, tw.innerW, segW + 0.005, { fill: PINK }, { fx: 'wipeU', dur: Math.round(step * w / m) + 150 });
      cm += m; cw += w;
      const nm = s.text(fmt(r100(cm)), { x: xM - 1.95, y: sc(cm) - 0.25, w: 1.8, h: 0.5, size: 24, bold: true, color: BLUE, align: 'right', valign: 'middle' }, { fx: 'fade', dur: 150, d: step - 150 });
      const nw = s.text(fmt(r100(cw)), { x: xW + g.tubeW + 0.15, y: sc(cw) - 0.25, w: 1.8, h: 0.5, size: 24, bold: true, color: PINK, align: 'left', valign: 'middle' }, { fx: 'fade', dur: 150, d: step - 150 });
      prev = { yr, nm, nw };
    });
    // Endstand: letzte Zähler weg, volle Säulen (für den Morph) + Endzahlen
    s.reg(prev.nm, { fx: 'out', a: true, dur: 150 }, 'sp'); s.reg(prev.nw, { fx: 'out', dur: 150 }, 'sp');
    s.rect(tm.cx - tm.innerW / 2, sc(cm), tm.innerW, sc(0) - sc(cm) + 0.12, { fill: BLUE, name: '!!mcol' }, { fx: 'fade', dur: 200 });
    s.rect(tw.cx - tw.innerW / 2, sc(cw), tw.innerW, sc(0) - sc(cw) + 0.12, { fill: PINK, name: '!!wcol' }, { fx: 'fade', dur: 200 });
    s.text('rund 22.000', { x: xM - 2.75, y: sc(cm) - 0.3, w: 2.6, h: 0.6, size: 30, bold: true, color: BLUE, align: 'right', valign: 'middle', name: '!!mnum' }, { fx: 'fade', dur: 200 });
    s.text('rund 7.000', { x: xW + g.tubeW + 0.15, y: sc(cw) - 0.3, w: 2.6, h: 0.6, size: 30, bold: true, color: PINK, align: 'left', valign: 'middle', name: '!!wnum' }, { fx: 'fade', dur: 200 });
    s.text('3 von 4 Verkehrstoten sind Männer.', { x: 5.1, y: 2.75, w: 3.2, h: 1.9, font: SERIF, size: 30, bold: true, color: COL.txt, align: 'center', valign: 'middle', fill: '161B24', line: BLUE, lw: 2, shape: pres.shapes.ROUNDED_RECTANGLE, rr: 0.1, rotate: -2, glow: 14, glowColor: BLUE, glowOp: 0.35, name: '!!stamp' }, { fx: 'stamp', c: true, dur: 450 });
    s.text([run('Fast 30.000 Menschen in 10 Jahren.', { bold: true, color: COL.orange }), run('  So viele Einwohner hat eine Kleinstadt.')], { x: 0.8, y: 6.5, w: 11.7, h: 0.45, font: SERIF, size: 22, align: 'center' }, { fx: 'rise', c: true, dur: 700 });
    s.text('Quelle: Statistisches Bundesamt, Verkehrstote 2016–2025 (29.217) · Aufteilung nach Geschlecht gerundet, Männeranteil rund 76 %', { x: 0.8, y: 7.12, w: 11.7, h: 0.3, size: 12, color: '9AA3AE', align: 'center', name: '!!src' });
  }

  // ---------- C · UND NACH ALTER? (Morph: Thermometer gehen auseinander) ----------
  {
    const s = deck.add({ bg: 'bg_black.jpg', transition: 'morph', dur: 1500, footer: false, notes: `
Die zwei Säulen gehen auseinander, in der Mitte entsteht die nächste Frage: Und nach Alter?
❓ Frage: Welche Altersgruppe hat die meisten Verkehrstoten? Raten lassen.
🖱 Klick 1: Die Balken wachsen. Überraschung: die meisten Toten sind Ältere ab 65. Ihr Körper verkraftet einen Unfall schlechter, viele sind zu Fuß oder mit dem Rad unterwegs.
🖱 Klick 2: 18–24 leuchtet auf. Das seid ihr. Ihr seid nur rund 7 % der Bevölkerung, stellt aber rund 11 % der Verkehrstoten.
Satz für die Klasse: Zwei Gruppen sind besonders gefährdet. Die Älteren, weil ihr Körper einen Unfall schlechter verkraftet. Und ihr, weil euch die Erfahrung fehlt.
Quelle: Destatis 2025 (unter 15 Jahre: 74, ab 65 Jahre: 1.115). 18–24 und 25–64 sind gerundete Werte.` });
    kicker(s, '10 Jahre auf deutschen Straßen', 0.8, 0.35, { w: 11.7, align: 'center', name: '!!k' });
    const g = { top: 3.45, tubeH: 2.75, tubeW: 0.62, bulb: 0.95 };
    const hM = (g.tubeH - 0.3) * 22200 / 24000, hW = (g.tubeH - 0.3) * 7000 / 24000, base = g.top + g.tubeH - 0.12;
    const xl = 1.1, xr = 11.6;
    thermo(s, COL, xl, BLUE, 'm', g);
    thermo(s, COL, xr, PINK, 'w', g);
    const cxL = xl + g.tubeW / 2, cxR = xr + g.tubeW / 2, iw = g.tubeW - 0.24;
    s.rect(cxL - iw / 2, base - hM, iw, hM + 0.12, { fill: BLUE, name: '!!mcol' });
    s.rect(cxR - iw / 2, base - hW, iw, hW + 0.12, { fill: PINK, name: '!!wcol' });
    s.text('rund 22.000', { x: xl - 0.75, y: g.top - 0.75, w: 2.15, h: 0.5, size: 20, bold: true, color: BLUE, align: 'center', name: '!!mnum' });
    s.text('rund 7.000', { x: xr - 0.75, y: g.top - 0.75, w: 2.15, h: 0.5, size: 20, bold: true, color: PINK, align: 'center', name: '!!wnum' });
    s.img(MARS, { x: xl - 0.45, y: 2.25, w: 0.3, h: 0.3, name: '!!msy' });
    s.text('Männer', { x: xl - 0.1, y: 2.2, w: 1.3, h: 0.4, size: 16, bold: true, color: BLUE, name: '!!mlab' });
    s.img(VENUS, { x: xr - 0.45, y: 2.25, w: 0.3, h: 0.3, name: '!!wsy' });
    s.text('Frauen', { x: xr - 0.1, y: 2.2, w: 1.3, h: 0.4, size: 16, bold: true, color: PINK, name: '!!wlab' });
    title(s, 'Und nach Alter?', 2.9, 1.0, 7.5, 0.9, { size: 44, align: 'center' }, { fx: 'fade', auto: true, dur: 900 });
    s.text('Verkehrstote 2025 nach Altersgruppe', { x: 2.9, y: 1.85, w: 7.5, h: 0.4, size: 17, color: COL.muted, align: 'center' }, { fx: 'fade', auto: true });
    const bars = [['unter 15', 74, '74'], ['18–24', 300, 'ca. 300'], ['25–64', 1300, 'ca. 1.300'], ['65+', 1115, '1.115']];
    const bw = 1.3, gap = 0.45, bx0 = 6.65 - (4 * bw + 3 * gap) / 2, bBase = 6.45, bMax = 3.0;
    s.lineS(bx0 - 0.2, bBase, bx0 + 4 * bw + 3 * gap + 0.2, bBase, { color: '3A4252', lw: 1.5 });
    bars.forEach(([l, v, lab], i) => {
      const x = bx0 + i * (bw + gap), h = bMax * v / 1300, young = i === 1;
      s.rrect(x, bBase - h, bw, h, { fill: young ? '4A5568' : '4A5568', rr: 0.05 }, { fx: 'wipeU', c: i === 0, a: i > 0, dur: 600 });
      s.text(lab, { x: x - 0.2, y: bBase - h - 0.5, w: bw + 0.4, h: 0.45, size: 19, bold: true, align: 'center' }, { fx: 'fade', dur: 300 });
      s.text(l, { x: x - 0.2, y: bBase + 0.08, w: bw + 0.4, h: 0.4, size: 17, color: COL.muted, align: 'center' });
    });
    { const x = bx0 + 1 * (bw + gap), h = bMax * 300 / 1300;
      s.rrect(x, bBase - h, bw, h, { fill: COL.orange, rr: 0.05, glow: 16, glowOp: 0.5, name: 'young' }, { fx: 'fade', c: true, dur: 500 });
      s.text('Das seid ihr.', { x: x - 0.8, y: bBase - h - 1.05, w: bw + 1.6, h: 0.5, font: SERIF, size: 24, bold: true, italic: true, color: COL.orange, align: 'center' }, { fx: 'stamp', a: true, dur: 400 }); }
    s.text([run('Nur rund 7 % der Bevölkerung', { color: COL.muted }), run('   ·   '), run('aber rund 11 % der Verkehrstoten', { color: COL.orange, bold: true })], { x: 2.9, y: 2.35, w: 7.5, h: 0.45, size: 19, align: 'center' }, { fx: 'rise', a: true, dur: 600 });
    s.text('Quelle: Destatis 2025 (unter 15 J.: 74, ab 65 J.: 1.115) · 18–24 und 25–64 gerundet', { x: 0.8, y: 7.12, w: 11.7, h: 0.3, size: 12, color: '9AA3AE', align: 'center', name: '!!src' });
  }

  // ---------- D · DIE POINTE ----------
  {
    const s = deck.add({ bg: 'bg_red.jpg', transition: 'black', footer: false, notes: `
Die Pointe. Langsam, Wort für Wort.
🖱 3 Klicks: Jung. Männlich. Frisch den Führerschein.
Dann: Das ist keine Beleidigung, das ist die Statistik. Und genau deshalb sitzen wir heute hier.
🖱 4. Klick: Die zwei häufigsten Unfallursachen bei jungen Fahrern: zu schnell und zu wenig Abstand. Das liegt nicht daran, dass junge Leute schlechter fahren. Es fehlt die Erfahrung, und viele überschätzen sich. Keine Panikmache, nur Realität.
Quelle Ursachen: Statistisches Bundesamt, Unfälle von 18- bis 24-Jährigen (Daten 2020): nicht angepasste Geschwindigkeit 19,7 %, zu geringer Abstand 19,2 %.` });
    kicker(s, 'Die gefährlichste Zeit kommt jetzt', 0.8, 1.2, { color: COL.red, w: 11.7, align: 'center' });
    title(s, 'Die gefährlichste Mischung:', 0.8, 1.6, 11.7, 1.0, { size: 44, align: 'center', color: COL.muted }, { fx: 'fade', auto: true, dur: 900 });
    ['Jung.', 'Männlich.', 'Frisch den Führerschein.'].forEach((w, i) => {
      s.text(w, { x: 0.8, y: 2.75 + i * 0.95, w: 11.7, h: 0.95, font: SERIF, size: 54, bold: true, color: i === 2 ? COL.orange : COL.txt, align: 'center', valign: 'middle', glow: i === 2 ? 14 : undefined, glowOp: 0.35 }, { fx: 'stamp', c: true, dur: 420 });
    });
    s.text([run('Häufigste Unfallursachen junger Fahrer: '), run('zu schnell', { bold: true, color: COL.txt }), run(' und '), run('zu wenig Abstand.', { bold: true, color: COL.txt })], { x: 0.8, y: 5.95, w: 11.7, h: 0.5, size: 22, color: COL.muted, align: 'center' }, { fx: 'rise', c: true, dur: 700 });
    s.text('Quelle: Statistisches Bundesamt, Unfälle von 18- bis 24-Jährigen im Straßenverkehr (Daten 2020)', { x: 0.8, y: 7.05, w: 11.7, h: 0.3, size: 12, color: '9AA3AE', align: 'center' });
  }
}
module.exports = { statsSlides };
